module.exports = function (plop) {
    // Generador para la estructura de Template React
    plop.setGenerator('template-react', {
        description: 'Crea la estructura de carpetas y archivos para el template React',
        prompts: [
            {
                type: 'input',
                name: 'name',
                message: 'Nombre del proyecto:'
            }
        ],
        actions: [
            {
                type: 'addMany',
                destination: '{{name}}/',
                templateFiles: ['templates_client/**', 'templates_client/.**', 'templates_client/.storybook/**'],
                skipIfExists: true
            }
        ]
    });
};