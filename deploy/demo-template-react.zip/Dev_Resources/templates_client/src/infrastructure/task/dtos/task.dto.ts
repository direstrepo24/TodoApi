export interface TaskRequestDto {
  id: number;
  name: string;
  complete: boolean;
}

export interface TaskDto {
  id: number;
  name: string;
  complete: boolean;
}
