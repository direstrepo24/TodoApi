import { di } from "@di/app.container";
import { TASK_SYMBOLS } from "@domain/tasks";
import { CompleteTaskUseCase } from "./commands/complete-task.usecase";
import { CreateTaskUseCase } from "./commands/create-task.usecase";
import { DeleteTaskByIdUseCase } from "./commands/delete-task-by-id.usecase";
import { AllTasksUseCase } from "./queries/all-tasks.usecase";
import { SearchTasksUseCase } from "./queries/search-tasks.usecase";

export class TaskUseCaseCreator {
  completeTaskUseCase() {
    return di.get<CompleteTaskUseCase>(TASK_SYMBOLS.TASK_COMPLETE);
  }

  createTaskUseCase() {
    return di.get<CreateTaskUseCase>(TASK_SYMBOLS.TASK_CREATE);
  }

  deleteTaskByIdUseCase() {
    return di.get<DeleteTaskByIdUseCase>(TASK_SYMBOLS.TASK_DELETE);
  }

  allTasksUseCase() {
    return di.get<AllTasksUseCase>(TASK_SYMBOLS.TASK_SEARCH);
  }

  searchTasksUseCase() {
    return di.get<SearchTasksUseCase>(TASK_SYMBOLS.TASK_SEARCH);
  }
}