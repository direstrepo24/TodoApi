import { inject, injectable } from "inversify";
import { Failure, Query, Result } from "@core/index";
import { TASK_SYMBOLS, TaskDom, type TaskRepository } from "@domain/tasks";

@injectable()
export class SearchTasksUseCase extends Query<
  Promise<Result<TaskDom[], Failure>>,
  string
> {
  constructor(
    @inject(TASK_SYMBOLS.TASK_REPOSITORY)
    private readonly _taskRepository: TaskRepository
  ) {
    super();
  }
  execute = (params: string): Promise<Result<TaskDom[], Failure>> =>
    this._taskRepository.search(params);
}
