import { UseCase } from "./use-case";
import { injectable } from "inversify";

@injectable()
export abstract class Query<Result = void, Params = void> extends UseCase<
  Result,
  Params
> {}
//NOSONAR
export abstract class NoParams {}
//NOSONAR
export abstract class NoResult {}
