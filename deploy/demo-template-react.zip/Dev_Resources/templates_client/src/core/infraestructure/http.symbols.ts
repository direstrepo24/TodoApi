export const HTTP_CLIENT_SYMBOLS = {
  AXIOS: Symbol("AXIOS"),
  FETCH: Symbol("FETCH"),
};
