export interface HttpClientOptions {
  path: string;
  body?: ReadableStream | XMLHttpRequestBodyInit | object;
  headers?: Record<string, string>;
  removeDefaultHeaders?: Array<string>;
  responseType?: ResponseType;
}

type ResponseType = "json" | "text" | "blob" | "arrayBuffer";

export interface HttpClientResponse<Result = unknown, Error = unknown> {
  /**Contains a Boolean indicating whether the response was successful (status in the range 200 to 299) or not. */
  ok: boolean;
  data: Result;
  error: Error;
  headers?: Record<string, string>;
  status?: number;
  statusText?: string;
}
