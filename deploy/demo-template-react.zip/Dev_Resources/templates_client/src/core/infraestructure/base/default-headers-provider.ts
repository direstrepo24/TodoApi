import { injectable } from "inversify";
import "reflect-metadata";
@injectable()
export class DefaultHeadersProvider {
  getHeaders(): Record<string, string> {
    return {
      Authorization: "Bearer your-auth-token",
      "Content-Type": "application/json",
    };
  }
}
