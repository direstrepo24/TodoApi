import { debounce, Debounce } from "@core/index";

describe("Debounce", () => {
  it("should execute the debounced class after the specified delay", async () => {
    //Prepare
    const mockFn = jest.fn();
    const delay = 2000;
    const debouncer = new Debounce(mockFn, delay);

    //Execute
    debouncer.execute("Hola");
    debouncer.execute("Hola de nuevo");
    await new Promise((resolve) => setTimeout(resolve, delay));

    //Assert
    expect(mockFn).toHaveBeenCalledTimes(1);
    expect(mockFn).toHaveBeenCalledWith("Hola de nuevo");
  });

  it("should execute the debounced function after the specified delay", async () => {
    //Prepare
    const mockFn = jest.fn();
    const delay = 2000;
    const debouncedFn = debounce(mockFn, delay);

    //Excute
    debouncedFn("Hola");
    debouncedFn("Hola de nuevo");
    await new Promise((resolve) => setTimeout(resolve, delay));

    //Assert
    expect(mockFn).toHaveBeenCalledTimes(1);
    expect(mockFn).toHaveBeenCalledWith("Hola de nuevo");
  });
});
