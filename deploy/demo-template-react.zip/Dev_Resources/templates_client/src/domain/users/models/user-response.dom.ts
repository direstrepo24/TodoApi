export class UserDom {
  constructor(
    public name: string | null = null,
    public userName: string | null = null,
    public email: string | null = null
  ) {}
}
