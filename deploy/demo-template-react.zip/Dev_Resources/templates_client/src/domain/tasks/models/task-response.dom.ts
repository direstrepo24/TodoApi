export class TaskDom {
  constructor(
    public id: number,
    public name: string,
    public completed: boolean
  ) {}
}
