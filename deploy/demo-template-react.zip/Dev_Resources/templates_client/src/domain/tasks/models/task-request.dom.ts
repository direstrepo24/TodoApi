export class CreateTaskRequestDom {
  constructor(
    public name: string,
    public complete: boolean = false
  ) {}
}
