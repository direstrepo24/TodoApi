import AppRoutes from "./routes/AppRoutes";
function App() {
  return (
    <div>
      <AppRoutes></AppRoutes>
    </div>
  );
}
export default App;
