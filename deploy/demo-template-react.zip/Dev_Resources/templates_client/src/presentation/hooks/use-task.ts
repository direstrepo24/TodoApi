import { useEffect, useState, useCallback } from "react";
import { debounce, Failure, NoParams, NoResult } from "@core/index";
import { CreateTaskRequestDom, TaskDom } from "@domain/tasks";
import {
  TaskUseCaseCreator
} from "@application/task";

function useTask(useCaseCreator: TaskUseCaseCreator) {
  const [tasks, setTasks] = useState<TaskDom[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<boolean>(false);
  const allTasksUseCase = useCaseCreator.allTasksUseCase();

  const debounceSearch = async (query: string) =>
    debounce(async () => {
      const useCase = useCaseCreator.searchTasksUseCase();
      const result = await useCase?.execute(query);
      result.fold(
        (data: TaskDom[]) => setTasks(data),
        (_: Failure) => setError(true)
      );
    }, 500);

  const searchTasks = async (query: string) => debounceSearch(query);

  const allTasks = useCallback(async () => {
    setLoading(true);
    const result = await allTasksUseCase?.execute(NoParams);
    result.fold(
      (data: TaskDom[]) => setTasks(data),
      (_: Failure) => setError(true)
    );
    setLoading(false);
  }, [allTasksUseCase]);

  const completeTask = async (id: number) => {
    const useCase = useCaseCreator.completeTaskUseCase();
    const result = await useCase?.execute(id);
    result.fold(
      (_: NoResult) => {
        allTasks();
      },
      (_: Failure) => setError(true)
    );
  };

  const deleteTask = async (id: number) => {
    const useCase = useCaseCreator.deleteTaskByIdUseCase();
    const result = await useCase?.execute(id);
    result.fold(
      (_: NoResult) => {
        allTasks();
      },
      (_: Failure) => setError(true)
    );
  };

  const addTask = async (newTask: CreateTaskRequestDom) => {
    const useCase = useCaseCreator.createTaskUseCase();
    const result = await useCase?.execute(newTask);
    result.fold(
      (_: TaskDom) => {
        allTasks();
      },
      (_: Failure) => setError(true)
    );
  };

  useEffect(() => {
    allTasks();
  }, [allTasks]);

  return {
    tasks,
    loading,
    error,
    completeTask,
    deleteTask,
    searchTasks,
    allTasks,
    addTask,
  };
}
export { useTask };
