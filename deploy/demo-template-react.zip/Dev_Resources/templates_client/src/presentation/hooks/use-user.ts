import { useState } from "react";
import { di } from "@di/index";
import { AllUsersUseCase } from "@application/users/index";
import { USER_SYMBOLS, UserDom } from "@domain/users/index";
import { Failure, NoParams } from "@core/index";

function useUser() {
  const allUsersUseCase = di.get<AllUsersUseCase>(USER_SYMBOLS.USER_LIST);
  const [users, setUsers] = useState<UserDom[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<boolean>(false);
  const handleAuth = async () => {
    setLoading(true);
    const resultData = await allUsersUseCase?.execute(NoParams);
    resultData.fold(
      (data: UserDom[]) => setUsers(data),
      (_: Failure) => setError(true)
    );
    setLoading(false);
  };
  return {
    users,
    loading,
    error,
    handleAuth,
  };
}
export { useUser };
