import { AllUsersUseCase } from "@application/users";
import { Left, Right } from "@core/index";
import { UserDom } from "@domain/users";
import { mock } from "jest-mock-extended";
import { renderHook, waitFor } from "@testing-library/react";
import { useUser } from "@presentation/hooks/use-user";

const allUsersUseCaseMock = mock<AllUsersUseCase>();

jest.mock("@di/index", () => ({
  di: {
    get: jest.fn(() => allUsersUseCaseMock),
  },
}));

describe("use user hook", () => {
  afterAll(() => {
    jest.restoreAllMocks();
  });
  it("should not show user, loading or error if handle auth is not executed", () => {
    // Arrange

    // Act
    const { result } = renderHook(() => useUser());

    // Assert
    expect(result.current.loading).toBe(true);
    expect(result.current.error).toBe(false);
    expect(result.current.users).toEqual([]);
  });
  it("should return users if function runs successfully", async () => {
    // Arrange
    const usersMock = [new UserDom("John Doe")];
    allUsersUseCaseMock.execute.mockResolvedValue(new Right(usersMock));

    // Act
    const { result } = renderHook(() => useUser());
    await result.current.handleAuth();
    await waitFor(() => result.current.loading === false);

    // Assert
    expect(result.current.loading).toBe(false);
    expect(result.current.error).toBe(false);
    expect(result.current.users).toEqual(usersMock);
  });
  it("should return error if function throw exception", async () => {
    // Arrange
    const errorMock = new Error("test");
    allUsersUseCaseMock.execute.mockResolvedValue(new Left(errorMock));

    // Act
    const { result } = renderHook(() => useUser());
    await result.current.handleAuth();
    await waitFor(() => result.current.loading === false);

    // Assert
    expect(result.current.loading).toBe(false);
    expect(result.current.error).toBe(true);
    expect(result.current.users).toEqual([]);
  });
});
