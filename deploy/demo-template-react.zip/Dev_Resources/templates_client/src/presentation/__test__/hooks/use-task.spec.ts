import { renderHook, waitFor } from "@testing-library/react";
import { CreateTaskRequestDom, TaskDom } from "@domain/tasks";
import { NoResult, Right } from "@core/index";
import { MockProxy, mock } from "jest-mock-extended";
import {
  TaskUseCaseCreator,
  AllTasksUseCase,
  CompleteTaskUseCase,
  CreateTaskUseCase,
  DeleteTaskByIdUseCase,
  SearchTasksUseCase,
} from "@application/task";
import { useTask } from "@presentation/hooks/use-task";

// Mock the tasks data
const mockTasks: TaskDom[] = [
  new TaskDom(1, "Task 1", false),
  new TaskDom(2, "Task 2", true),
  new TaskDom(3, "Task 3", false),
];

const mockNewTask: CreateTaskRequestDom = new CreateTaskRequestDom(
  "Task 4",
  false
);
const mockTaskResponse: TaskDom = new TaskDom(4, mockNewTask.name, true);

describe("useTask test", () => {
  let allTasksUseCaseMock: MockProxy<AllTasksUseCase>;
  let completeTaskUseCaseMock: MockProxy<CompleteTaskUseCase>;
  let deleteTaskUseCaseMock: MockProxy<DeleteTaskByIdUseCase>;
  let searchTasksUseCaseMock: MockProxy<SearchTasksUseCase>;
  let createTaskUseCaseMock: MockProxy<CreateTaskUseCase>;
  let useCaseCreatorMock: MockProxy<TaskUseCaseCreator>;

  beforeEach(() => {
    allTasksUseCaseMock = mock<AllTasksUseCase>();
    completeTaskUseCaseMock = mock<CompleteTaskUseCase>();
    deleteTaskUseCaseMock = mock<DeleteTaskByIdUseCase>();
    searchTasksUseCaseMock = mock<SearchTasksUseCase>();
    createTaskUseCaseMock = mock<CreateTaskUseCase>();
    useCaseCreatorMock = mock<TaskUseCaseCreator>();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  async function callUseTask() {
    const { result } = renderHook(() =>
      useTask(useCaseCreatorMock)
    );
    await waitFor(() => {
      return result.current.loading === false;
    });
    return result;
  }

  test("should all tasks on initial render", async () => {
    // Arrange
    allTasksUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom[]>(mockTasks))
    );
    useCaseCreatorMock.allTasksUseCase.mockReturnValue(allTasksUseCaseMock);

    // Act
    const { current } = await callUseTask();
    current.allTasks();
    
    // Assert
    expect(current.tasks.length).toBe(mockTasks.length);
  });

  test("should filter tasks on call searchTasks", async () => {
    // Arrange
    allTasksUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom[]>(mockTasks))
    );
    searchTasksUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom[]>(mockTasks))
    );
    useCaseCreatorMock.allTasksUseCase.mockReturnValue(allTasksUseCaseMock);
    useCaseCreatorMock.searchTasksUseCase.mockReturnValue(searchTasksUseCaseMock);

    // Act
    const { current } = await callUseTask();
    await current.searchTasks("Task");

    // Assert
    expect(current.tasks.length).toBe(mockTasks.length);
  });

  test("should create task on call addTask", async () => {
    // Arrange
    allTasksUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom[]>(mockTasks))
    );
    createTaskUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom>(mockTaskResponse))
    );
    useCaseCreatorMock.allTasksUseCase.mockReturnValue(allTasksUseCaseMock);
    useCaseCreatorMock.createTaskUseCase.mockReturnValue(createTaskUseCaseMock);

    // Act
    const { current } = await callUseTask();
    await current.addTask(mockNewTask);

    // Assert
    expect(current.tasks).toBe(mockTasks);
  });

  test("should complete task on call completeTask", async () => {
    // Arrange
    allTasksUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom[]>(mockTasks))
    );
    completeTaskUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom>(mockTaskResponse))
    );
    useCaseCreatorMock.allTasksUseCase.mockReturnValue(allTasksUseCaseMock);
    useCaseCreatorMock.completeTaskUseCase.mockReturnValue(completeTaskUseCaseMock);

    // Act
    const { current } = await callUseTask();
    await current.completeTask(4);

    // Assert
    expect(current.tasks).toBe(mockTasks);
  });

  test("should delete task on call deleteTask", async () => {
    // Arrange
    allTasksUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<TaskDom[]>(mockTasks))
    );
    deleteTaskUseCaseMock.execute.mockReturnValue(
      Promise.resolve(new Right<NoResult>(NoResult))
    );
    useCaseCreatorMock.allTasksUseCase.mockReturnValue(allTasksUseCaseMock);
    useCaseCreatorMock.deleteTaskByIdUseCase.mockReturnValue(deleteTaskUseCaseMock);

    // Act
    const { current } = await callUseTask();
    await current.deleteTask(4);

    // Assert
    expect(current.tasks).toBe(mockTasks);
  });
});
