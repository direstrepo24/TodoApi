import SimpleDatePicker from "@presentation/components/atomic/organisms/SimpleDatePicker";
import { months } from "@presentation/components/atomic/organisms/SimpleDatePicker/utils/constants";
import { render, screen } from "@testing-library/react";
import { format, getMonth, getYear } from "date-fns";
import selectEvent from "react-select-event";

describe("Simple date picker component", () => {
  describe("idle", () => {
    it("Should display all months", async () => {
      // Arrange
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker />
        </form>
      );

      selectEvent.openMenu(screen.getByLabelText("Mes"));
      const currentOptions = await screen.findAllByRole("option");

      // Assert
      expect(currentOptions).toHaveLength(months.length);
    });
    it("should display all days", async () => {
      // Arrange
      const firstMonthLength = 31;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker />
        </form>
      );

      selectEvent.openMenu(screen.getByLabelText("Día"));
      const currentOptions = await screen.findAllByRole("option");

      // Assert
      expect(currentOptions).toHaveLength(firstMonthLength);
    });
    it("should display 20 years range into year picker", async () => {
      // Arrange
      const yearRange = 21;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker />
        </form>
      );

      selectEvent.openMenu(screen.getByLabelText("Año"));
      const currentOptions = await screen.findAllByRole("option");

      // Assert
      expect(currentOptions).toHaveLength(yearRange);
    });
    it("should display default value if component has it", async () => {
      // Arrange
      const currentDate = new Date();
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker date={currentDate} />
        </form>
      );

      // Assert
      expect(screen.getByTestId("form")).toHaveFormValues({
        year: getYear(currentDate).toString(),
        month: getMonth(currentDate).toString(),
        day: format(currentDate, "d"),
      });
    });
  });

  describe("changing options", () => {
    it("should show the first day of the first month 10 years ago, choosing first year option", async () => {
      // Arrange
      const currentDate = new Date();
      const tenYearsAgoLabel = (getYear(currentDate) - 10).toString();
      const expectedDateValues = {
        year: tenYearsAgoLabel,
        month: "0",
        day: "1",
      };
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Año"), tenYearsAgoLabel);

      // Assert
      expect(screen.getByTestId("form")).toHaveFormValues(expectedDateValues);
    });
    it("should show the current day of the selected month into the current year, choosing second month option", async () => {
      // Arrange
      const currentDate = new Date();
      const expectedDateValues = {
        year: getYear(currentDate).toString(),
        month: "1",
        day: format(currentDate, "d"),
      };
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker date={currentDate} />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Mes"), "Febrero");

      // Assert
      expect(screen.getByTestId("form")).toHaveFormValues(expectedDateValues);
    });
    it("should show current month 2nd one year ago, choosing year and day", async () => {
      // Arrange
      const currentDate = new Date();
      const yearAgoLabel = (getYear(currentDate) - 1).toString();
      const expectedDateValues = {
        year: yearAgoLabel,
        month: getMonth(currentDate).toString(),
        day: "2",
      };
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker date={currentDate} />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Año"), yearAgoLabel);
      await selectEvent.select(screen.getByLabelText("Día"), "2");

      // Assert
      expect(screen.getByTestId("form")).toHaveFormValues(expectedDateValues);
    });

    it("should call on change when user changes any value", async () => {
      // Arrange
      const currentDate = new Date();
      const onChangeMock = jest.fn();
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker date={currentDate} onChange={onChangeMock} />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Mes"), "Febrero");

      // Assert
      expect(onChangeMock).toHaveBeenCalled();
    });
  });

  describe("setting limits", () => {
    it("if set limits as 3/12/2014 to 10/12/2014, should show right day options, selecting december", async () => {
      // Arrange
      const minDate = new Date(2014, 11, 3);
      const maxDate = new Date(2014, 11, 10);

      const expectedOptionsLength = 8;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker minDate={minDate} maxDate={maxDate} />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Mes"), "Diciembre");

      selectEvent.openMenu(screen.getByLabelText("Día"));
      const dayOptions = await screen.findAllByRole("option");

      // Assert
      expect(dayOptions).toHaveLength(expectedOptionsLength);
    });
    it("if set limits as 21/02/2014 to 10/12/2014, should show right year option", async () => {
      // Arrange
      const minDate = new Date(2014, 1, 21);
      const maxDate = new Date(2014, 11, 10);

      const expectedOptionsLength = 1;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker minDate={minDate} maxDate={maxDate} />
        </form>
      );

      selectEvent.openMenu(screen.getByLabelText("Año"));
      const yearOptions = await screen.findAllByRole("option");

      // Assert
      expect(yearOptions).toHaveLength(expectedOptionsLength);
    });
    it("if set limits as 21/02/2014 to 10/12/2014, should show right month options", async () => {
      // Arrange
      const minDate = new Date(2014, 1, 21);
      const maxDate = new Date(2014, 11, 10);

      const expectedOptionsLength = 11;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker minDate={minDate} maxDate={maxDate} />
        </form>
      );

      selectEvent.openMenu(screen.getByLabelText("Mes"));
      const monthOptions = await screen.findAllByRole("option");

      // Assert
      expect(monthOptions).toHaveLength(expectedOptionsLength);
    });

    it("if set limits as 21/02/2014 to 10/5/2015, should show right month options, when user select 2015", async () => {
      // Arrange
      const minDate = new Date(2014, 1, 21);
      const maxDate = new Date(2015, 4, 10);

      const expectedOptionsLength = 5;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker minDate={minDate} maxDate={maxDate} />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Año"), "2015");

      selectEvent.openMenu(screen.getByLabelText("Mes"));
      const monthOptions = await screen.findAllByRole("option");

      // Assert
      expect(monthOptions).toHaveLength(expectedOptionsLength);
    });

    it("if set limits as 21/02/2014 to 10/5/2015, should show right month options, when user select may 2015", async () => {
      // Arrange
      const minDate = new Date(2014, 1, 21);
      const maxDate = new Date(2015, 4, 10);

      const expectedOptionsLength = 10;
      // Act
      render(
        <form data-testid="form">
          <SimpleDatePicker minDate={minDate} maxDate={maxDate} />
        </form>
      );

      await selectEvent.select(screen.getByLabelText("Año"), "2015");
      await selectEvent.select(screen.getByLabelText("Mes"), "Mayo");

      selectEvent.openMenu(screen.getByLabelText("Día"));
      const monthOptions = await screen.findAllByRole("option");

      // Assert
      expect(monthOptions).toHaveLength(expectedOptionsLength);
    });
  });
});
