import Checkbox from "@presentation/components/atomic/atoms/Checkbox";
import { fireEvent, render, screen } from "@testing-library/react";

describe("Checkbox component", () => {
  it("should render correctly", () => {
    // Arrange
    render(<Checkbox />);
    const checkbox = screen.getByRole("checkbox");

    // Act

    // Assert
    expect(checkbox).toBeInTheDocument();
  });
  it("should handle change state correctly", () => {
    /// Arrange
    const handleChange = jest.fn();
    render(<Checkbox name="test" onValueChange={handleChange} />);
    const checkbox = screen.getByRole("checkbox");

    // Act
    fireEvent.click(checkbox);

    // Assert
    expect(handleChange).toHaveBeenCalledTimes(1);
  });

  it("should not change state if checkbox is disabled", () => {
    // Arrange
    const defaultValue = false;
    const disabledClass = "tuya-checkbox--disabled";
    render(<Checkbox name="test" defaultValue={defaultValue} disabled />);
    const checkbox = screen.getByRole("checkbox");
    const checkboxButton = screen.getByRole("button");

    // Act
    fireEvent.click(checkbox);

    // Assert
    expect(checkbox).not.toBeChecked();
    expect(checkboxButton).toHaveClass(disabledClass);
  });
});
