import Icon from "@presentation/components/atomic/atoms/Icons";
import { icons } from "@presentation/components/atomic/atoms/Icons/icons";
import { fireEvent, render, screen } from "@testing-library/react";

describe("Icon Component", () => {
  it("should render correctly", () => {
    // Arrange
    render(<Icon />);
    const icon = screen.getByRole("img");
    // Act

    // Assert
    expect(icon).toBeInTheDocument();
  });

  it("should do onClick event if icon allow it", () => {
    // Arrange
    const handleClick = jest.fn();
    render(<Icon onClick={handleClick} />);
    const icon = screen.getByRole("img");

    // Act
    fireEvent.click(icon);

    // Assert
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("should renter 'tarjeta' icon as a default", () => {
    // Arrange
    const tarjetaSrc = icons["tarjeta"];
    render(<Icon />);
    const icon = screen.getByRole("img");

    // Act

    // Assert
    expect(icon).toHaveAttribute("src", tarjetaSrc.src);
  });
});
