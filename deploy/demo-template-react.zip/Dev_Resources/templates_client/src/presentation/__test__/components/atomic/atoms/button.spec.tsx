import Button, { BtnColor } from "@presentation/components/atomic/atoms/Button";
import { fireEvent, render, screen } from "@testing-library/react";

describe("Button component", () => {
  it("should render correctly", () => {
    // Arrange
    const textButton = "test";
    render(<Button>{textButton}</Button>);
    const button = screen.getByRole("button");

    // Act

    // Assert
    expect(button).toHaveTextContent(textButton);
  });

  it("should do onClick event when user clicks it", () => {
    // Arrange
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>test</Button>);
    const button = screen.getByRole("button");

    // Act
    fireEvent.click(button);

    // Assert
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  describe("button color", () => {
    const variations: BtnColor[] = ["primary", "secondary", "third"];
    for (const variation of variations) {
      it(`should set class correctly according to the choice (${variation})`, () => {
        // Arrange
        const btnColor = variation;
        render(<Button btnColor={btnColor}>test</Button>);
        const button = screen.getByRole("button");

        // Act

        // Assert
        expect(button).toHaveClass(`tuya-btn--${btnColor}`);
      });
    }
  });
});
