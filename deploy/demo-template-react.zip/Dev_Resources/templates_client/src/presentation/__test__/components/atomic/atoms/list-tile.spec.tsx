import ListTile from "@presentation/components/atomic/atoms/ListTile";
import { render, screen } from "@testing-library/react";

describe("ListTile Component", () => {
  it("should render leading", () => {
    // Arrange
    const leadingText = "test";
    render(<ListTile leading={leadingText} />);
    const listTile = screen.getByText(leadingText);
    // Act

    // Assert
    expect(listTile).toBeInTheDocument();
  });
  it("should render subtitle", () => {
    // Arrange
    const subtitleText = "test";
    render(<ListTile subtitle={subtitleText} />);
    const listTile = screen.getByText(subtitleText);
    // Act

    // Assert
    expect(listTile).toBeInTheDocument();
  });
  it("should render title", () => {
    // Arrange
    const titleText = "test";
    render(<ListTile title={titleText} />);
    const listTile = screen.getByText(titleText);
    // Act

    // Assert
    expect(listTile).toBeInTheDocument();
  });
  it("should render trailing", () => {
    // Arrange
    const trailingText = "test";
    render(<ListTile trailing={trailingText} />);
    const listTile = screen.getByText(trailingText);
    // Act

    // Assert
    expect(listTile).toBeInTheDocument();
  });
});
