import ExternalLink from "@presentation/components/atomic/atoms/Links/ExternalLink";
import { render, screen } from "@testing-library/react";

describe("ExternalLink Component", () => {
  it("should render correctly", () => {
    // Arrange
    const externalUrl = "www.example.com";
    render(<ExternalLink href={externalUrl} label="go to example" />);
    const link = screen.getByRole("link");

    // Act

    // Assert
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute("href", externalUrl);
  });

  it("should set correct class if link is disabled", () => {
    // Arrange
    const externalUrl = "www.example.com";
    const disabledClass = "tuya-link--disabled";
    render(
      <ExternalLink href={externalUrl} aria-disabled label="go to example" />
    );
    const link = screen.getByRole("link");

    // Act

    // Assert
    expect(link).toHaveClass(disabledClass);
  });
});
