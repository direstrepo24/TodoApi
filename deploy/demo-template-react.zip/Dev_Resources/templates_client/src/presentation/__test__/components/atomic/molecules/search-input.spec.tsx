import SearchInput from "@presentation/components/atomic/molecules/SearchInput";
import { fireEvent, render, screen } from "@testing-library/react";

describe("Input search component", () => {
  it("should show default placeholder if user doesn`t change it", () => {
    // Arrange
    const defaultPlaceholder = "Buscar";
    // Act
    render(<SearchInput />);
    const $input =
      screen.getByPlaceholderText<HTMLInputElement>(defaultPlaceholder);

    // Assert
    expect($input).toBeInTheDocument();
  });
  it("should show other placeholder if user change it", () => {
    // Arrange
    const customPlaceholder = "Buscar usuarios";
    // Act
    render(<SearchInput placeholder={customPlaceholder} />);
    const $input =
      screen.getByPlaceholderText<HTMLInputElement>(customPlaceholder);

    // Assert
    expect($input).toBeInTheDocument();
  });
  it("should change input value when user writes into it", () => {
    // Arrange
    const defaultPlaceholder = "Buscar";
    // Act
    render(<SearchInput />);
    const $input =
      screen.getByPlaceholderText<HTMLInputElement>(defaultPlaceholder);

    fireEvent.change($input, { target: { value: "Test" } });

    // Assert
    expect($input.value).toBe("Test");
  });
  it("should call onClick only if user clicks search icon", () => {
    // Arrange
    const defaultPlaceholder = "Buscar";
    const handleClick = jest.fn((e) => e.preventDefault());
    // Act
    render(
      <form>
        <SearchInput onClick={handleClick} />
      </form>
    );
    const $input =
      screen.getByPlaceholderText<HTMLInputElement>(defaultPlaceholder);
    const $icon = $input.nextElementSibling;
    if ($icon) fireEvent.click($icon);

    // Assert
    expect(handleClick).toHaveBeenCalled();
  });
});
