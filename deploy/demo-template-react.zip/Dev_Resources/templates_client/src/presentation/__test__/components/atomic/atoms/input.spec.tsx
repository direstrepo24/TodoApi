import Input from "@presentation/components/atomic/atoms/Input";
import { fireEvent, render, screen } from "@testing-library/react";

describe("Input Component", () => {
  it("should render correctly", () => {
    // Arrange
    render(<Input />);
    const input = screen.getByRole("textbox");

    // Act

    // Assert
    expect(input).toBeInTheDocument();
  });
  it("should update value when writing", () => {
    // Arrange
    const newValue = "test";
    render(<Input />);
    const input = screen.getByRole("textbox");

    // Act
    fireEvent.change(input, { target: { value: newValue } });

    // Assert
    expect(input).toHaveValue(newValue);
  });
  it("should set correct class if input has an error", () => {
    // Arrange
    const error = {
      text: "Field is required",
      class: "tuya-input__field--error",
    };
    render(<Input error={error.text} />);
    const input = screen.getByRole("textbox");
    const errorText = screen.getByText(error.text);

    // Act

    // Assert
    expect(input).toHaveClass(error.class);
    expect(errorText).toBeInTheDocument();
  });
});
