import RadioGroup, {
  RadioGroupOption,
} from "@presentation/components/atomic/molecules/Radio/RadioGroup";
import { fireEvent, render, screen } from "@testing-library/react";
import { useState } from "react";

describe("RadioGroup component", () => {
  it("should show all options", () => {
    // Arrange
    const options: RadioGroupOption[] = [
      {
        label: "test 1",
        value: "test 1",
      },
      {
        label: "test 2",
        value: "test 2",
      },
      {
        label: "test 3",
        value: "test 3",
      },
    ];
    render(
      <form>
        <RadioGroup options={options} name="test" />
      </form>
    );
    const radioOptions = screen.getAllByRole("radio");
    // Act

    // Assert
    expect(radioOptions).toHaveLength(options.length);
  });

  it("should change value when user click an option", () => {
    // Arrange
    const name = "test";
    const options: RadioGroupOption[] = [
      {
        label: "test 1",
        value: "test 1",
      },
      {
        label: "test 2",
        value: "test 2",
      },
      {
        label: "test 3",
        value: "test 3",
      },
    ];
    const RadioWrapper = () => {
      const [selected, setSelected] = useState<string>();

      return (
        <form data-testid="form">
          <RadioGroup
            options={options}
            name={name}
            selectedValue={selected}
            onValueChange={setSelected}
          />
        </form>
      );
    };
    render(<RadioWrapper />);
    const firstOption = screen.getByText(options[0].label);

    // Act
    fireEvent.click(firstOption);

    // Arrange
    const radioGroup = screen.getByTestId("form");

    // Assert
    expect(radioGroup).toHaveFormValues({
      [name]: options[0].value,
    });
  });
});
