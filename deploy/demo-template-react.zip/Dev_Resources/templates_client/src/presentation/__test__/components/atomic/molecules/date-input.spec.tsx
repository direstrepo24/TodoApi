import DateInput from "@presentation/components/atomic/molecules/DateInput";
import { fireEvent, render, screen } from "@testing-library/react";
import { getYear } from "date-fns";
import { useState } from "react";
import { DateRange } from "react-day-picker";
import selectEvent from "react-select-event";
describe("Date input component", () => {
  it("should show label at the first render", () => {
    // Arrange
    const label = "Selecciona tu fecha";
    // Act
    render(
      <DateInput
        mode="single"
        maxDate={new Date(2025, 11, 31)}
        minDate={new Date(2023, 0, 1)}
        label={label}
      />
    );
    const currentLabelMessage = screen.getByText(label);

    // Assert
    expect(currentLabelMessage).toBeInTheDocument();
  });
  it("should show error message if error message exists", () => {
    // Arrange
    const error = "El campo es obligatorio";

    // Act
    render(
      <DateInput
        mode="single"
        maxDate={new Date(2025, 11, 31)}
        minDate={new Date(2023, 0, 1)}
        label={"Selecciona tu fecha"}
        error={error}
      />
    );
    const currentErrorMessage = screen.getByText(error);

    // Assert
    expect(currentErrorMessage).toBeInTheDocument();
  });

  it("should set a default range of 20 years difference", () => {
    // Arrange
    const label = "Selecciona tu fecha";
    const currentYear = getYear(new Date());
    const range = {
      min: currentYear - 10,
      max: currentYear + 10,
    };
    render(<DateInput mode="single" label={label} />);
    const dateInput = screen.getByText(label);

    // Act
    fireEvent.click(dateInput);

    // Arrange
    const currentYearSelect = screen.getByText(currentYear);

    // Act
    selectEvent.openMenu(currentYearSelect);

    // Arrange
    const minYear = screen.getByText(range.min);
    const maxYear = screen.getByText(range.max);

    // Assert
    expect(minYear).toBeInTheDocument();
    expect(maxYear).toBeInTheDocument();
  });

  it("should throw error if range dates are not correct", () => {
    // Arrange
    const renderError = () => {
      render(
        <DateInput
          minDate={new Date(2030, 0, 1)}
          maxDate={new Date(2010, 0, 1)}
          mode="single"
        />
      );
    };

    // Act

    // Assert
    expect(renderError).toThrow();
  });

  describe("choosing dates", () => {
    const extractDays = (dates: string) => {
      const regex = /(\d{2})-\d{2}-\d{4}/g;
      let match;
      const days = [];

      while ((match = regex.exec(dates)) !== null) {
        days.push(Number(match[1]));
      }

      return days;
    };
    it("should choose single date", async () => {
      // Arrange
      const label = "Selecciona tu fecha";
      const selectedDay = 1;

      const DateInputWrapper = ({ label }: { label: string }) => {
        const [selectedDate, setSelectedDate] = useState<Date>();

        return (
          <DateInput
            mode="single"
            maxDate={new Date(2030, 11, 31)}
            minDate={new Date(2023, 0, 1)}
            label={label}
            placeholder={label}
            selected={selectedDate}
            onSelect={setSelectedDate}
          />
        );
      };
      // Act
      render(<DateInputWrapper label={label} />);

      const button = screen.getByText(label);
      fireEvent.click(button);
      const firstDayOfCurrentMonth = screen.getAllByText(selectedDay);
      fireEvent.click(firstDayOfCurrentMonth[0]);

      const expectedResultElement =
        screen.getByPlaceholderText<HTMLInputElement>(label);
      expect(expectedResultElement).toBeDefined();
      // Assert
      if (expectedResultElement.value) {
        expect(extractDays(expectedResultElement.value)).toStrictEqual([
          selectedDay,
        ]);
      }
    });
    it("should choose multiple date", async () => {
      // Arrange
      const label = "Selecciona tu fecha";
      const selectedDays = [1, 3];

      const DateInputWrapper = ({ label }: { label: string }) => {
        const [selectedDate, setSelectedDate] = useState<Date[]>();

        return (
          <DateInput
            mode="multiple"
            maxDate={new Date(2030, 11, 31)}
            minDate={new Date(2023, 0, 1)}
            label={label}
            placeholder={label}
            selected={selectedDate}
            onSelect={setSelectedDate}
          />
        );
      };
      // Act
      render(<DateInputWrapper label={label} />);

      const button = screen.getByText(label);
      fireEvent.click(button);
      const firstDayOfCurrentMonth = screen.getAllByText(selectedDays[0]);
      fireEvent.click(firstDayOfCurrentMonth[0]);
      const thirdDayOfCurrentMonth = screen.getAllByText(selectedDays[1]);
      fireEvent.click(thirdDayOfCurrentMonth[0]);

      const expectedResultElement =
        screen.getByPlaceholderText<HTMLInputElement>(label);
      expect(expectedResultElement).toBeDefined();
      // Assert
      if (expectedResultElement.value) {
        expect(extractDays(expectedResultElement.value)).toStrictEqual(
          selectedDays
        );
      }
    });
    it("should choose range date", async () => {
      // Arrange
      const label = "Selecciona tu fecha";
      const selectedDays = [1, 3];

      const DateInputWrapper = ({ label }: { label: string }) => {
        const [selectedDate, setSelectedDate] = useState<DateRange>();

        return (
          <DateInput
            mode="range"
            maxDate={new Date(2030, 11, 31)}
            minDate={new Date(2023, 0, 1)}
            label={label}
            placeholder={label}
            selected={selectedDate}
            onSelect={setSelectedDate}
          />
        );
      };
      // Act
      render(<DateInputWrapper label={label} />);

      const button = screen.getByText(label);
      fireEvent.click(button);
      const firstDayOfCurrentMonth = screen.getAllByText(selectedDays[0]);
      fireEvent.click(firstDayOfCurrentMonth[0]);
      const thirdDayOfCurrentMonth = screen.getAllByText(selectedDays[1]);
      fireEvent.click(thirdDayOfCurrentMonth[0]);

      const expectedResultElement =
        screen.getByPlaceholderText<HTMLInputElement>(label);
      expect(expectedResultElement).toBeDefined();
      // Assert
      if (expectedResultElement.value) {
        expect(extractDays(expectedResultElement.value)).toStrictEqual(
          selectedDays
        );
      }
    });
  });
});
