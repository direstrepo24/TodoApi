import InternalLink from "@presentation/components/atomic/atoms/Links/InternalLink";
import { fireEvent, render, screen } from "@testing-library/react";
import { BrowserRouter, useLocation } from "react-router-dom";

const LocationDisplay = () => {
  const location = useLocation();

  return <div data-testid="location-display">{location.pathname}</div>;
};

describe("ExternalLink Component", () => {
  it("should render correctly", () => {
    // Arrange
    const internalUrl = "/test";
    const internalUrlRegex = /\/test/;
    render(
      <BrowserRouter>
        <InternalLink to={internalUrl} label="go to example" />
      </BrowserRouter>
    );
    const link = screen.getByRole("link");

    // Act

    // Assert
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute(
      "href",
      expect.stringMatching(internalUrlRegex)
    );
  });

  it("should redirect to expected relative path, when user clicks", () => {
    // Arrange
    const internalUrl = "/test";
    render(
      <BrowserRouter>
        <InternalLink to={internalUrl} label="go to example" />
        <LocationDisplay />
      </BrowserRouter>
    );
    const link = screen.getByRole("link");
    const locationDisplay = screen.getByTestId("location-display");

    // Act
    fireEvent.click(link);

    // Assert
    expect(locationDisplay).toHaveTextContent(internalUrl);
  });

  it("should set correct class if link is disabled", () => {
    // Arrange
    const internalUrl = "/test";
    const disabledClass = "tuya-link--disabled";
    render(
      <BrowserRouter>
        <InternalLink to={internalUrl} disabled label="go to example" />
      </BrowserRouter>
    );
    const link = screen.getByRole("link");

    // Act

    // Assert
    expect(link).toHaveClass(disabledClass);
  });
});
