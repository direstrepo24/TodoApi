import Card from "@presentation/components/atomic/atoms/Card";
import { render, screen } from "@testing-library/react";

describe("Card component", () => {
  it("should render correctly", () => {
    // Arrange
    const cardText = "test";
    render(<Card>{cardText}</Card>);
    const card = screen.getByText(cardText);

    // Act

    // Assert
    expect(card).toHaveTextContent(cardText);
  });

  it("should have card class", () => {
    // Arrange
    const cardClass = "tuya-card";
    const cardText = "test";
    render(<Card>{cardText}</Card>);
    const card = screen.getByText(cardText);

    // Act

    // Assert
    expect(card).toHaveClass(cardClass);
  });
});
