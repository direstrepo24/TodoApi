import IconLink from "@presentation/components/atomic/molecules/Link/IconLink";
import { render, screen } from "@testing-library/react";

describe("IconLink component", () => {
  it("should render correctly", () => {
    // Arrange
    const label = "test";
    render(<IconLink label={label} />);
    const iconLink = screen.getByText(label);
    const icon = screen.getByRole("img");
    // Act

    // Assert
    expect(iconLink).toBeInTheDocument();
    expect(icon).toBeInTheDocument();
  });

  it("should set class correctly if link is disabled", () => {
    // Arrange
    const label = "test";
    render(<IconLink label={label} aria-disabled />);
    const iconLink = screen.getByText(label);
    const parent = iconLink.parentElement as HTMLElement;

    // Act

    // Assert
    expect(parent).toHaveClass("tuya-icon-link--disabled");
  });
});
