import SelectInput from "@presentation/components/atomic/molecules/SelectInput";
import { render, screen } from "@testing-library/react";
import selectEvent from "react-select-event";
describe("Select custom input component", () => {
  it("should show label at the first render", () => {
    // Arrange
    const label = "¿Cuál es tu ocupación?";
    // Act
    render(<SelectInput label={label} />);
    const currentLabelMessage = screen.getByText(label);

    // Assert
    expect(currentLabelMessage).toBeInTheDocument();
  });
  it("should not show options at the first render", () => {
    // Arrange
    const options = [
      { label: "Estudiante", value: "1" },
      { label: "Empleado tiempo completo", value: "2" },
      { label: "Empleado tiempo parcial", value: "3" },
      { label: "Trabajador independiente", value: "4" },
      { label: "Empresario", value: "5" },
      { label: "Profesional", value: "6" },
    ];
    // Act
    render(<SelectInput label={"¿Cuál es tu ocupación?"} options={options} />);
    const firstOption = screen.queryByText(options[0].label);

    // Assert
    expect(firstOption).not.toBeInTheDocument();
  });
  it("should show error message if error message exists", () => {
    // Arrange
    const error = "El campo es obligatorio";

    // Act
    render(
      <SelectInput
        label={"¿Cuál es tu ocupación?"}
        options={[
          { label: "Estudiante", value: "1" },
          { label: "Empleado tiempo completo", value: "2" },
          { label: "Empleado tiempo parcial", value: "3" },
          { label: "Trabajador independiente", value: "4" },
          { label: "Empresario", value: "5" },
          { label: "Profesional", value: "6" },
        ]}
        error={error}
      />
    );
    const currentErrorMessage = screen.getByText(error);

    // Assert
    expect(currentErrorMessage).toBeInTheDocument();
  });
  it("should choose option", async () => {
    // Arrange
    const label = "¿Cuál es tu ocupación?";
    const options = [
      { label: "Estudiante", value: "1" },
      { label: "Empleado tiempo completo", value: "2" },
      { label: "Empleado tiempo parcial", value: "3" },
      { label: "Trabajador independiente", value: "4" },
      { label: "Empresario", value: "5" },
      { label: "Profesional", value: "6" },
    ];
    // Act
    render(
      <form data-testid="form">
        <SelectInput
          label={label}
          options={options}
          name="occupation"
          inputId="occupation"
        />
      </form>
    );

    await selectEvent.select(screen.getByLabelText(label), options[0].label);

    // Assert
    expect(screen.getByTestId("form")).toHaveFormValues({
      occupation: options[0].value,
    });
  });
  it("should display the correct number of options", async () => {
    // Arrange
    const label = "¿Cuál es tu ocupación?";
    const options = [
      { label: "Estudiante", value: "1" },
      { label: "Empleado tiempo completo", value: "2" },
      { label: "Empleado tiempo parcial", value: "3" },
      { label: "Trabajador independiente", value: "4" },
      { label: "Empresario", value: "5" },
      { label: "Profesional", value: "6" },
    ];
    // Act
    render(
      <form data-testid="form">
        <SelectInput
          label={label}
          options={options}
          name="occupation"
          inputId="occupation"
        />
      </form>
    );

    selectEvent.openMenu(screen.getByLabelText(label));
    const currentOptions = await screen.findAllByRole("option");

    // Assert
    expect(currentOptions).toHaveLength(options.length);
  });
});
