import TextCard from "@presentation/components/atomic/molecules/Cards/TextCard";
import { render, screen } from "@testing-library/react";

describe("TextCard Component", () => {
  it("should render component properly", () => {
    // Arrange
    const texts = {
      title: "lorem",
      subtitle: "ipsum",
      subtitleTrailing: "dolor",
    };
    render(
      <TextCard
        title={texts.title}
        subtitle={texts.subtitle}
        subtitleTrailing={texts.subtitleTrailing}
      />
    );
    const textCard = screen.getByText(texts.title);

    // Act

    // Assert
    expect(textCard).toBeInTheDocument();
  });
});
