import RadioButton from "@presentation/components/atomic/atoms/RadioButton";
import { fireEvent, render, screen } from "@testing-library/react";

describe("RadioButton Component", () => {
  it("should render correctly", () => {
    // Arrange
    render(<RadioButton />);
    const radioButton = screen.getByRole("radio");
    // Act

    // Assert
    expect(radioButton).toBeInTheDocument();
  });
  it("should be checked when the check prop is true", () => {
    // Arrange
    render(<RadioButton checked />);
    const radioButton = screen.getByRole("radio");

    // Act

    // Assert
    expect(radioButton).toBeChecked();
  });
  it("should call onChange when clicked", () => {
    // Arrange
    const handleChange = jest.fn();
    const value = "test";
    render(<RadioButton value={value} onChange={handleChange} />);
    const radioButton = screen.getByRole("radio");

    // Act
    fireEvent.click(radioButton);

    // Assert
    expect(handleChange).toHaveBeenCalledTimes(1);
  });
});
