import IconButton from "@presentation/components/atomic/molecules/Buttons/IconButton";
import { fireEvent, render, screen } from "@testing-library/react";

describe("IconButton Component", () => {
  it("should render component correctly", () => {
    // Arrange
    const label = "test";
    render(<IconButton icon="icoSistemaBuscar" label={label} />);
    const iconButton = screen.getByText(label);
    const icon = screen.getByRole("img");
    // Act

    // Assert
    expect(iconButton).toBeInTheDocument();
    expect(icon).toBeInTheDocument();
  });
  it("should show another element if iconChildren prop exists", () => {
    // Arrange
    const label = "test";
    const MockIcon = () => <span>icon</span>;

    // Act
    render(<IconButton label={label} iconChildren={<MockIcon />} />);
    const iconButton = screen.getByText("icon");

    // Assert
    expect(iconButton).toBeInTheDocument();
  });

  it("should execute onClick if user click icon", () => {
    // Arrange
    const handleClick = jest.fn();
    render(
      <IconButton onClick={handleClick} icon="icoSistemaBuscar" label="test" />
    );
    const icon = screen.getByRole("img");

    // Act
    fireEvent.click(icon);

    // Assert
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
