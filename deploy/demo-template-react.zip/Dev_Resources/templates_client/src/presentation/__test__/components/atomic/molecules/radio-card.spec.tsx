import RadioCard from "@presentation/components/atomic/molecules/Cards/RadioCard";
import { fireEvent, render, screen } from "@testing-library/react";

describe("CheckCard Component", () => {
  it("should render correctly", () => {
    // Arrange
    render(<RadioCard name="test" value="test" />);
    const checkCard = screen.getByRole("radio");
    // Act

    // Assert
    expect(checkCard).toBeInTheDocument();
  });
  it("should call onValueChange if user clicks card", () => {
    // Arrange
    const props = {
      name: "test",
      value: "test",
      onValueChange: jest.fn(),
      title: "lorem",
      subtitle: "ipsum",
    };
    render(<RadioCard {...props} />);
    const checkCard = screen.getByText(props.title);

    // Act
    fireEvent.click(checkCard);

    // Assert
    expect(props.onValueChange).toHaveBeenCalledTimes(1);
  });
});
