import type { Meta, StoryObj } from "@storybook/react";

import Input from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/Input",
  component: Input,
  tags: ["autodocs"],
  argTypes: {
    name: {
      control: "text",
      description: "Asocia el identificador del componente",
    },
    defaultValue: {
      control: "text",
      description: "Opcional permite asociar el valor por defecto a mostrar",
    },
    error: {
      control: "text",
      description: "Opcional para mostrar un mensaje de error",
    },
    className: {
      control: "text",
      description:
        "Permite agregar una o varias clases CSS al campo de entrada.",
    },
    placeholder: {
      control: "text",
      description:
        "Proporciona un texto de marcador de posición que se muestra dentro del campo de entrada antes de que el usuario escriba algo",
    },
    label: {
      control: "text",
      description:
        "Esta propiedad permite asociar un texto de etiqueta al campo de entrada",
    },
    minLength: {
      control: "number",
      description:
        "Establece la longitud mínima permitida para el valor del campo de entrada.",
    },
    maxLength: {
      control: "number",
      description:
        "Define la longitud máxima permitida para el valor del campo de entrada.",
    },
    required: {
      control: "boolean",
      description: " Indica si el campo de entrada es obligatorio. ",
    },
    disabled: {
      control: "boolean",
      description:
        "Esta propiedad especifica si el campo de entrada debe estar deshabilitado. ",
    },
    onValueChange: {
      action: "function",
      description:
        "Es una función de devolución de llamada que se ejecuta cuando el valor del campo cambia",
    },
    type: {
      control: {
        type: "select",
        options: ["text", "number"],
      },
      description: "Permite establecer el tipo de input ('text', 'number').",
    },
    autoComplete: {
      control: {
        type: "select",
        options: ["on", "off"],
      },
      description:
        "Controla la función de autocompletado del navegador para el campo de entrada.",
    },
  },
} satisfies Meta<typeof Input>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Default: Story = {
  args: {
    label: "Escribe tu número de documento",
    placeholder: "Ejemplo",
  },
};
