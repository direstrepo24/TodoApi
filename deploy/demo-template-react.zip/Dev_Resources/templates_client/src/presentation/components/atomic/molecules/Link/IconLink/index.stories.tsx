import type { Meta, StoryObj } from "@storybook/react";

import IconLink from "./index";
import { icons } from "@presentation/components/atomic/atoms/Icons/icons";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/IconLink",
  component: IconLink,
  tags: ["autodocs"],
  argTypes: {
    icon: {
      options: Object.keys(icons),
      control: {
        type: "select",
      },
      description:
        "Recibe el nombre del icono a mostrar en pantalla, configure sus iconos en la ruta: atoms/Icons/icons.ts",
    },
    href: {
      control: "text",
      description:
        "Representa la URL o dirección a la que se redirigirá el enlace cuando se haga clic.",
    },
    className: {
      control: "text",
      description:
        "Permite agregar clases CSS adicionales al componente de enlace",
    },
    label: {
      control: "text",
      description:
        "Representa el texto principal o etiqueta que se mostrará en el enlace",
    },
    "aria-disabled": {
      control: "boolean",
      description: "Indica si el enlace está deshabilitado o no",
    },
    target: {
      control: {
        type: "select",
        options: ["_blank", "_parent", "_self", "_top"],
      },
      description:
        "Define cómo se abrirá la URL cuando se haga clic en el enlace (por ejemplo, en una nueva pestaña o en la misma)",
    },
    iconSize: {
      control: {
        type: "select",
        options: ["22", "32", "48"],
      },
      description: "Establecer tamaño al icono, 32 por defecto",
    },
  },
} satisfies Meta<typeof IconLink>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args
export const Default: Story = {
  args: {
    label: "link-reference",
  },
};

export const Disabled: Story = {
  args: {
    label: "link-reference",
    "aria-disabled": true,
  },
};
