import classNames from "classnames";
import { getMonth, getYear } from "date-fns";
import { FC, ReactElement } from "react";
import { DropdownProps, IconDropdown, useNavigation } from "react-day-picker";
import Select, { SingleValue } from "react-select";

type YearMonthOption = {
  id: string;
  label: string;
  value: number;
};

export function CustomDropdown(props: Readonly<DropdownProps>): JSX.Element {
  const { goToMonth, currentMonth } = useNavigation();
  const children = props.children as ReactElement<{
    children: string;
    value: number;
  }>[];

  const options: YearMonthOption[] =
    children.map(({ props: { children, value } }) => ({
      id: props.name as string,
      label: children,
      value,
    })) ?? [];

  const option = options.find((option) => {
    if (option.id === "years") {
      return option.value === getYear(currentMonth);
    }
    if (option.id === "months") {
      return option.value === getMonth(currentMonth);
    }
  });

  const handleChange = (option: SingleValue<YearMonthOption>) => {
    if (!option) return;
    const { id, value } = option;
    const month = new Date(currentMonth);

    if (id === "years") {
      month.setFullYear(value);
    }

    if (id === "months") {
      month.setMonth(value);
    }

    goToMonth(month);
  };

  return (
    <Select
      options={options}
      value={option}
      onChange={handleChange}
      className="tuya-date-select__dropdown"
      theme={(defaultThemes) => ({
        ...defaultThemes,
        colors: {
          ...defaultThemes.colors,
          primary: "#eaeaea",
          primary25: "#eaeaea",
          primary50: "#eaeaea",
          primary75: "#eaeaea",
        },
      })}
      classNames={{
        control: () =>
          classNames(
            "tuya-date-select__dropdown-control",
            option?.id === "months"
              ? "tuya-date-select__dropdown-control--month"
              : "tuya-date-select__dropdown-control--year"
          ),
        valueContainer: () => "tuya-date-select__dropdown-value-container",
        option: () => "tuya-date-select__dropdown-option",
        menuList: () => "tuya-date-select__dropdown-menu-list",
      }}
      components={{
        IndicatorSeparator: () => null,
        DropdownIndicator: CustomDropdownIcon,
      }}
    />
  );
}

const CustomDropdownIcon: FC = () => (
  <IconDropdown className="tuya-date-select__dropdown-icon" />
);
