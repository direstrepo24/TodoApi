import type { Meta, StoryObj } from "@storybook/react";
import { icons } from "./icons";
import Icon from ".";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/Icons",
  component: Icon,
  tags: ["autodocs"],
  argTypes: {
    width: {
      control: "number",
      description: "Ancho personalizado para el ícono",
    },
    height: {
      control: "number",
      description: "Alto personalizado para el ícono",
    },
    icon: {
      options: Object.keys(icons),
      control: {
        type: "select",
      },
      description:
        "Recibe el nombre del icono a mostrar en pantalla, configure sus iconos en la ruta: atoms/Icons/icons.ts",
    },
    iconSize: {
      options: ["22", "32", "48"],
      control: {
        type: "select",
      },
      description: "Establecer tamaño al icono, 32 por defecto",
    },
    className: {
      control: "text",
      description: "Clase CSS adicional para el contenedor",
    },
    onClick: {
      action: "clicked",
      description: "Función de clic para el ícono",
    },
  },
} satisfies Meta<typeof Icon>;

export default meta;
type Story = StoryObj<typeof meta>;
export const Default: Story = {
  args: {
    icon: "tarjeta",
  },
};

// Componente para mostrar todos los iconos
const AllIconsDisplay = () => {
  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 gap-2.5">
      {Object.keys(icons).map((iconName) => (
        <div key={iconName} className="flex flex-col items-center mt-5">
          <Icon icon={iconName as keyof typeof icons} />
          <span className="text-xs mt-3">{iconName}</span>
        </div>
      ))}
    </div>
  );
};

// Historia que muestra todos los iconos
export const AllIcons: StoryObj<typeof Icon> = {
  render: () => <AllIconsDisplay />,
};
