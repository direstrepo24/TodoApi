import RadioButton from "@presentation/components/atomic/atoms/RadioButton";
import { FC } from "react";
import "./index.scss";

type LabelPosition = "top" | "bottom" | "left" | "right";

export interface RadioGroupOption {
  label: string;
  value: string;
}

interface RadioGroupProps {
  name: string;
  options: RadioGroupOption[];
  labelPosition?: LabelPosition;
  selectedValue?: string | null; // valor seleccionado
  onValueChange?: (value: string) => void; // valor del check
  className?: string;
}

const RadioGroup: FC<RadioGroupProps> = ({
  name,
  labelPosition = "right",
  options,
  selectedValue,
  onValueChange,
  className,
}) => {
  return (
    <div className={className}>
      {options.map((option) => (
        <div key={option.value}>
          <RadioButton
            labelPosition={labelPosition}
            label={option.label}
            value={option.value}
            name={name}
            onChange={(e) => onValueChange && onValueChange(e.target.value)}
            checked={option.value == selectedValue}
          />
        </div>
      ))}
    </div>
  );
};

export default RadioGroup;
