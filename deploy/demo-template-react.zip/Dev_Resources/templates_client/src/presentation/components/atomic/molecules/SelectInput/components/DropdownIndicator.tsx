import classNames from "classnames";
import { DropdownIndicatorProps, GroupBase, components } from "react-select";
import Icon from "@presentation/components/atomic/atoms/Icons";

function DropdownIndicator<
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>(props: DropdownIndicatorProps<Option, IsMulti, Group>) {
  const className = classNames(
    props.className,
    "tuya-select__icon",
    props.isFocused && "rotate"
  );
  return (
    <components.DropdownIndicator {...props} className={className}>
      <Icon icon="icoSistemaFlechaAbajo" iconSize="32" />
    </components.DropdownIndicator>
  );
}

export { DropdownIndicator };
