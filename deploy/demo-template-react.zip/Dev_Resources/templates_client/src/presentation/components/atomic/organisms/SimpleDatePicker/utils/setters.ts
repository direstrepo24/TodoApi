import { max, min, setDate, setMonth, setYear } from "date-fns";

export function setInRangeDate(
  value: Date,
  minDate: Date,
  maxDate: Date
): Date {
  return max([min([maxDate, value]), minDate]);
}

interface SetSelectedValueProps {
  newValue: number;
  currentDate: Date;
  minDate: Date;
  maxDate: Date;
}
export function setSelectedYear({
  currentDate,
  newValue,
  maxDate,
  minDate,
}: SetSelectedValueProps) {
  return setInRangeDate(setYear(currentDate, newValue), minDate, maxDate);
}

export function setSelectedMonth({
  currentDate,
  maxDate,
  minDate,
  newValue,
}: SetSelectedValueProps) {
  return setInRangeDate(setMonth(currentDate, newValue), minDate, maxDate);
}

export function setSelectedDay({
  currentDate,
  maxDate,
  minDate,
  newValue,
}: SetSelectedValueProps) {
  return setInRangeDate(setDate(currentDate, newValue), minDate, maxDate);
}
