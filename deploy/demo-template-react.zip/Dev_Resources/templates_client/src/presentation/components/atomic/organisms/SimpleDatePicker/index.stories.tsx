import type { Meta, StoryObj } from "@storybook/react";

import SimpleDatePicker from "./index";
import { useState } from "react";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Organisms/SimpleDatePicker",
  component: SimpleDatePicker,
  tags: ["autodocs"],
  argTypes: {
    maxDate: {
      control: "date",
      description: "limite superior para la elección de fechas",
    },
    minDate: {
      control: "date",
      description: "limite inferior para la elección de fechas",
    },
    error: {
      control: "text",
      description: "Permite mostrar un mensaje de error",
    },
    date: {
      control: "date",
      description: "valor de fecha actual",
    },
    onChange: {
      description:
        "callback que tiene como parámetro el nuevo valor de la fecha seleccionada, útil para actualizar algún estado",
    },
  },
} satisfies Meta<typeof SimpleDatePicker>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Default: Story = {
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 400,
        background: "inherit",
      },
    },
  },
};

export const AddingLimits: Story = {
  args: {
    minDate: new Date(2014, 0, 5),
    maxDate: new Date(2014, 10, 3),
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 400,
        background: "inherit",
      },
    },
  },
};

export const ErrorStory: Story = {
  args: {
    error: "Información respecto al input o info adicional.",
  },
  name: "Error",
};

const ParentComponent = () => {
  const [date, setDate] = useState(new Date());
  return (
    <div>
      <div>Initial parent date: {new Date().toLocaleString()}</div>
      <div>Updated date: {date.toLocaleString()}</div>
      <SimpleDatePicker date={date} onChange={(newDate) => setDate(newDate)} />
    </div>
  );
};

export const Parent: Story = {
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 400,
        background: "inherit",
      },
    },
  },
  render: ParentComponent,
};
