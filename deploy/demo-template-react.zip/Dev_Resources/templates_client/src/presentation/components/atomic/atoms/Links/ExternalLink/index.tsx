import { AnchorHTMLAttributes, FC } from "react";
import "./index.scss";
import classNames from "classnames";

export interface ExternalLinkProps
  extends AnchorHTMLAttributes<HTMLAnchorElement> {
  label?: string;
  className?: string;
}

const ExternalLink: FC<ExternalLinkProps> = ({
  label,
  "aria-disabled": ariaDisabled,
  className,
  ...props
}) => {
  const linkClass = classNames(
    "tuya-link",
    ariaDisabled && "tuya-link--disabled",
    className
  );
  return (
    <a {...props} className={linkClass}>
      {label}
    </a>
  );
};

export default ExternalLink;
