import classNames from "classnames";
import { ControlProps, GroupBase, components } from "react-select";

export interface CustomControlProps<
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
> extends ControlProps<Option, IsMulti, Group> {
  readonly label?: string;
  readonly error?: boolean;
  readonly htmlFor?: string;
}
function Control<
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>(props: CustomControlProps<Option, IsMulti, Group>) {
  const labelClassName = classNames(
    "tuya-select__label",
    (!props.hasValue || props.isFocused) && "tuya-select__label--is-active",
    (props.hasValue || props.isFocused) && "tuya-select__label--is-floating"
  );

  const controlClassName = classNames(
    props.className,
    props.error && "tuya-select__control--error"
  );

  return (
    <>
      <components.Control {...props} className={controlClassName} />
      {props.label && (
        <label className={labelClassName} htmlFor={props.htmlFor}>
          {props.label}
        </label>
      )}
    </>
  );
}

function ControlWrapper<
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>(
  controlProps: ControlProps<Option, IsMulti, Group>,
  label?: string,
  error?: boolean,
  htmlFor?: string
) {
  return Control({
    ...controlProps,
    label: label,
    error: error,
    htmlFor: htmlFor,
  });
}

export { Control, ControlWrapper };
