import { Options } from "react-select";
import { DateOption } from "../../types";
import { format, getDaysInMonth, getMonth, getYear } from "date-fns";
import { months } from "./constants";

interface GetAvailableYearsProps {
  minDate: Date;
  maxDate: Date;
}

export function getAvailableYears({
  maxDate,
  minDate,
}: GetAvailableYearsProps): Options<DateOption> {
  const years = [];
  for (let year = getYear(minDate); year <= getYear(maxDate); year++) {
    years.push({ value: year, label: year.toString() });
  }
  return years;
}

interface GetAvailableMonthsProps {
  selectedYear: number;
  minDate: Date;
  maxDate: Date;
}
export function getAvailableMonths({
  selectedYear,
  minDate,
  maxDate,
}: GetAvailableMonthsProps) {
  if (getYear(minDate) === selectedYear && getYear(maxDate) === selectedYear) {
    const maxMonth = getMonth(maxDate);
    const minMonth = getMonth(minDate);
    return months.filter((_, idx) => idx >= minMonth && idx <= maxMonth);
  }

  if (getYear(minDate) === selectedYear) {
    const minMonth = getMonth(minDate);
    return months.filter((_, idx) => idx >= minMonth);
  }

  if (getYear(maxDate) === selectedYear) {
    const maxMonth = getMonth(maxDate);
    return months.filter((_, idx) => idx <= maxMonth);
  }

  return months;
}

interface GetAvailableDaysProps {
  selectedYear: number;
  selectedMonth: number;
  minDate: Date;
  maxDate: Date;
}

export function getAvailableDays({
  selectedYear,
  selectedMonth,
  minDate,
  maxDate,
}: GetAvailableDaysProps) {
  const currentYear = new Date(selectedYear, selectedMonth, 1);
  const daysInMonth = getDaysInMonth(currentYear);
  const days = [];

  for (let day = 1; day <= daysInMonth; day++) {
    days.push({ value: day, label: day.toString() });
  }

  if (
    getYear(minDate) === selectedYear &&
    getMonth(minDate) === selectedMonth &&
    getYear(maxDate) === selectedYear &&
    getMonth(maxDate) === selectedMonth
  ) {
    const maxDay = Number(format(maxDate, "d"));
    const minDay = Number(format(minDate, "d"));
    return days.filter((day) => day.value >= minDay && day.value <= maxDay);
  }

  if (
    getYear(minDate) === selectedYear &&
    getMonth(minDate) === selectedMonth
  ) {
    const minDay = Number(format(minDate, "d"));
    return days.filter((day) => day.value >= minDay);
  }

  if (
    getYear(maxDate) === selectedYear &&
    getMonth(maxDate) === selectedMonth
  ) {
    const minDay = Number(format(maxDate, "d"));
    return days.filter((day) => day.value <= minDay);
  }

  return days;
}
