import { DetailedHTMLProps, FC, HTMLAttributes, ReactNode } from "react";
import "./index.scss";
import classNames from "classnames";

interface ListTileProps
  extends DetailedHTMLProps<HTMLAttributes<HTMLDivElement>, HTMLDivElement> {
  title?: string; //Opcionalmente titulo principal
  subtitle?: string; // Opcionalmente un subtitulo debajo del titulo
  leading?: ReactNode; //para mostrar antes del titulo
  trailing?: ReactNode; //para mostrar despues del titulo
}

const ListTile: FC<ListTileProps> = ({
  title,
  subtitle,
  leading,
  trailing,
  className,
  ...props
}) => {
  const listtileClass = classNames("tuya-listtile", className);
  return (
    <div {...props} className={listtileClass}>
      {leading && <div className="tuya-listtile__leading">{leading}</div>}
      <div className="tuya-listtile__text-container">
        {title && <div className="tuya-listtile__title">{title}</div>}
        {subtitle && <div className="tuya-listtile__subtitle">{subtitle}</div>}
      </div>
      {trailing && <div className="tuya-listtile__trailing">{trailing} </div>}
    </div>
  );
};

export default ListTile;
