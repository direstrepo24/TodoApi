import { DetailedHTMLProps, FC, InputHTMLAttributes, ReactNode } from "react";
import "./index.scss";
import classNames from "classnames";

type LabelPosition = "top" | "bottom" | "left" | "right";

interface RadioButtonProps
  extends Omit<
    DetailedHTMLProps<InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>,
    "type"
  > {
  label?: ReactNode;
  labelPosition?: LabelPosition;
}

const RadioButton: FC<RadioButtonProps> = ({
  label,
  labelPosition,
  className,
  ...props
}) => {
  const radioContentClass = classNames(
    "tuya-radio-content",
    labelPosition,
    className
  );
  return (
    <label className={radioContentClass}>
      <div className="tuya-radio__label">{label}</div>
      <div className="tuya-radio__button">
        <input {...props} className="tuya-radio__button__input" type="radio" />
        <i className="tuya-radio__button__icon"></i>
      </div>
    </label>
  );
};
export default RadioButton;
