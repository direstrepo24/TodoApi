import { FC } from "react";
import "./index.scss";
import classNames from "classnames";
import Icon, {
  IconProps,
  IconSize,
} from "@presentation/components/atomic/atoms/Icons";
import ExternalLink, {
  ExternalLinkProps,
} from "@presentation/components/atomic/atoms/Links/ExternalLink";

interface IconLinkProps extends ExternalLinkProps {
  icon?: IconProps["icon"];
  iconSize?: IconSize;
  className?: string;
}

const IconLink: FC<IconLinkProps> = ({
  icon = "sistemaNotificacion",
  iconSize = "22",
  className,
  "aria-disabled": ariaDisabled,
  ...props
}) => {
  const iconLinkClass = classNames(
    "tuya-icon-link",
    ariaDisabled && "tuya-icon-link--disabled",
    className
  );
  return (
    <div className={iconLinkClass}>
      <Icon className="tuya-icon-link__icon" iconSize={iconSize} icon={icon} />
      <ExternalLink
        {...props}
        className="tuya-icon-link__link"
        aria-disabled={ariaDisabled}
      />
    </div>
  );
};

export default IconLink;
