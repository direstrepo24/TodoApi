import type { Meta, StoryObj } from "@storybook/react";

import ListTile from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/ListTile",
  component: ListTile,
  tags: ["autodocs"],
  argTypes: {
    id: {
      control: "text",
      description: "Identificador del componente.",
    },
    title: {
      control: "text",
      description: "titulo principal (Opcional).",
    },
    subtitle: {
      control: "text",
      description: "Un subtitulo debajo del titulo (Opcional)",
    },
    leading: {
      control: "text",
      description: "Componente o Elemento HTML a mostrar antes del titulo",
    },
    trailing: {
      control: "text",
      description: "Componente o Elemento HTML a mostrar después del titulo",
    },
  },
} satisfies Meta<typeof ListTile>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args
export const Default: Story = {
  args: {
    title: "Hora Transaccion",
    trailing: <strong>3:09:28 p.m</strong>,
  },
};

export const Base: Story = {
  args: {
    subtitle: "Hora Transaccion",
    trailing: <p>3:09:28 p.m</p>,
  },
};

export const Title: Story = {
  args: {
    title: "Titulo",
    subtitle: "Subtitulo",
  },
};
