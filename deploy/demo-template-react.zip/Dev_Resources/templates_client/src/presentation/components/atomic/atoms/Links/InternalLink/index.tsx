import { FC } from "react";
import "./index.scss";
import classNames from "classnames";
import { Link, LinkProps } from "react-router-dom";

export interface InternalLinkProps extends LinkProps {
  label?: string;
  disabled?: boolean;
  className?: string;
}

const InternalLink: FC<InternalLinkProps> = ({
  label,
  disabled = false,
  className,
  to,
  ...props
}) => {
  const linkClass = classNames(
    "tuya-link",
    disabled && "tuya-link--disabled",
    className
  );
  return (
    <Link {...props} to={disabled ? "#" : to} className={linkClass}>
      {label}
    </Link>
  );
};

export default InternalLink;
