import type { Meta, StoryObj } from "@storybook/react";

import TextCard from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/TextCard",
  component: TextCard,
  tags: ["autodocs"],
  argTypes: {
    id: {
      control: "text",
      description: "Identificador del componente.",
    },
    title: {
      control: "text",
      description: "titulo principal (Opcional).",
    },
    subtitle: {
      control: "text",
      description: "Un subtitulo debajo del titulo (Opcional)",
    },
    subtitleTrailing: {
      control: "text",
      description: "Subtitulo después del titulo (Opcional)",
    },
  },
} satisfies Meta<typeof TextCard>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args
export const Default: Story = {
  args: {
    id: "checkCard1",
    title: "Titulo",
  },
};

export const Subtitle: Story = {
  args: {
    id: "checkCard1",
    title: "Titulo",
    subtitle: "Subtitulo",
  },
};

export const SubtitleTrailing: Story = {
  args: {
    id: "checkCard1",
    title: "Titulo",
    subtitleTrailing: "Subtitulo",
  },
};
