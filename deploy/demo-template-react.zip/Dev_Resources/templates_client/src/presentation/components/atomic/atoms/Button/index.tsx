import { FC, ButtonHTMLAttributes } from "react";
import "./index.scss";
import classNames from "classnames";

export type BtnColor = "primary" | "secondary" | "third";
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  btnColor?: BtnColor;
}

const Button: FC<ButtonProps> = ({
  children,
  className,
  btnColor = "primary",
  ...props
}) => {
  const btnClass = classNames("tuya-btn", `tuya-btn--${btnColor}`, className);
  return (
    <button className={btnClass} {...props}>
      {children}
    </button>
  );
};

export default Button;
