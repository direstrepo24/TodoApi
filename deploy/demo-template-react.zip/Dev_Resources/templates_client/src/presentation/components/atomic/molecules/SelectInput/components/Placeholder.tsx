import { GroupBase, PlaceholderProps, components } from "react-select";

const Placeholder = <
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>(
  placeholderProps: PlaceholderProps<Option, IsMulti, Group>
) =>
  placeholderProps.isFocused && (
    <components.Placeholder {...placeholderProps} />
  );

export { Placeholder };
