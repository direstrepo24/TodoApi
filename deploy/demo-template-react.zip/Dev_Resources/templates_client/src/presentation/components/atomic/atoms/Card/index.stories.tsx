import type { Meta, StoryObj } from "@storybook/react";

import Card from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/Card",
  component: Card,
  tags: ["autodocs"],

  argTypes: {
    id: {
      control: "text",
      description: "Identificador del componente.",
    },
    children: {
      control: "text",
      description: "Anidar contenido (texto o elementos HTML).",
    },
    className: {
      control: "text",
      description: "Clases TailwindCSS adicionales para personalizar el estilo",
    },
    onClick: {
      action: "clicked",
      description:
        "Función que se ejecutara, cuando se haga clic en la tarjeta",
    },
  },
} satisfies Meta<typeof Card>;

export default meta;
type Story = StoryObj<typeof meta>;
// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Empty: Story = {
  args: {
    id: "card1",
  },
};

export const Text: Story = {
  args: {
    id: "card2",
    children: <h5>Titulo</h5>,
  },
};
