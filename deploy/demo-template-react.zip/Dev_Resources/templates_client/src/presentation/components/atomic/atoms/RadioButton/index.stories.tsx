import type { Meta, StoryObj } from "@storybook/react";

import RadioButton from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/RadioButton",
  component: RadioButton,
  tags: ["autodocs"],
  argTypes: {
    name: {
      control: "text",
      description: "Nombre del radio button.",
    },
    label: {
      control: "text",
      description: "Texto que se muestra para el radiobutton.",
    },
    labelPosition: {
      control: {
        type: "select",
        options: ["top", "bottom", "left", "right"],
      },
      description: "Permite modificar la posición del label.",
    },
    checked: {
      control: "boolean",
      description: "Valor asociado al Radiobutton",
    },
  },
} satisfies Meta<typeof RadioButton>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Default: Story = {
  args: {
    name: "radiobutton1",
    value: "test",
    label: "Radio de prueba",
    labelPosition: "left",
  },
};
