import type { Meta, StoryObj } from "@storybook/react";
import IconButton from ".";
import Icon from "@presentation/components/atomic/atoms/Icons";
import { icons } from "@presentation/components/atomic/atoms/Icons/icons";
import { action } from "@storybook/addon-actions";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/IconButton",
  component: IconButton,
  tags: ["autodocs"],
  argTypes: {
    label: {
      control: "text",
      description: "Texto que se mostrara en el botón",
    },
    icon: {
      options: Object.keys(icons),
      control: {
        type: "select",
      },
      description:
        "Recibe el nombre del icono a mostrar en pantalla, configure sus iconos en la ruta: atoms/Icons/icons.ts",
    },
    iconSize: {
      control: {
        type: "select",
        options: ["22", "32", "48"],
      },
      description: "Establecer tamaño al icono, 32 por defecto",
    },
    iconChildren: {
      control: "object",
      description:
        "Nodo React para contenido de ícono personalizado (opcional)",
    },
    className: {
      control: "text",
      description:
        "Clases TailwindCSS adicionales para personalizar el estilo del botón",
    },
    onClick: {
      action: "clicked",
      description: "Función que se ejecutará cuando se haga clic en el botón",
    },
    disabled: {
      control: "boolean",
      description: "Permite deshabilitar el botón",
    },
    btnColor: {
      control: {
        type: "select",
        options: ["primary", "secondary"],
      },
      description: "Tipo de estilo del botón (primario, secundario).",
    },
  },
} satisfies Meta<typeof IconButton>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Primary: Story = {
  args: {
    label: "Primario",
    btnColor: "primary",
    icon: "tarjeta",
    onClick: action("clicked"),
  },
};

export const Secondary: Story = {
  args: {
    label: "Secundario",
    btnColor: "secondary",
    icon: "tarjeta",
  },
};

export const IconChildren: Story = {
  args: {
    label: "Primario",
    color: "primary",
    iconChildren: <Icon icon={"tarjeta"} width={15} height={15}></Icon>,
  },
};
