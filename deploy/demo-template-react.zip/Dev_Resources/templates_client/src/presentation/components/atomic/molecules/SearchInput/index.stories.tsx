import type { Meta, StoryObj } from "@storybook/react";

import SearchInput from ".";

const meta = {
  title: "Tuya Template/Molecules/SearchInput",
  component: SearchInput,
  tags: ["autodocs"],
  argTypes: {
    onClick: {
      action: "clicked",
      description:
        "Función que se ejecuta cuando se hace click en el ícono de la lupa",
    },
    placeholder: {
      control: "text",
      description:
        "Texto que se muestra inicialmente antes de empezar a escribir en el buscador",
    },
  },
} satisfies Meta<typeof SearchInput>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    onClick: () => {
      alert("search icon clicked");
    },
  },
};
