import Select, { Props as PropsReactSelect, GroupBase } from "react-select";
import classNames from "classnames";

import { ControlWrapper, DropdownIndicator, Placeholder } from "./components";
import "./index.scss";

interface TSelectInput<
  Option,
  IsMulti extends boolean,
  Group extends GroupBase<Option>,
> extends PropsReactSelect<Option, IsMulti, Group> {
  label?: string;
  error?: string;
  hasError?: boolean;
}

function SelectInput<
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>({
  className,
  label,
  error,
  hasError,
  ...props
}: TSelectInput<Option, IsMulti, Group>) {
  return (
    <>
      <div className={classNames("tuya-select", className)}>
        <Select
          {...props}
          className="tuya-select-container"
          classNamePrefix="tuya-select"
          theme={(defaultThemes) => ({
            ...defaultThemes,
            colors: {
              ...defaultThemes.colors,
              primary: "#eaeaea",
              primary25: "#eaeaea",
              primary50: "#eaeaea",
              primary75: "#eaeaea",
            },
          })}
          components={{
            DropdownIndicator,
            Control: (controlProps) =>
              ControlWrapper(
                controlProps,
                label,
                hasError || !!error,
                props.name
              ),
            Placeholder,
            IndicatorSeparator: () => null,
          }}
        />
      </div>
      {error && (
        <div>
          <span className="tuya-select__error-label">{error}</span>
        </div>
      )}
    </>
  );
}

export default SelectInput;
