import type { Meta, StoryObj } from "@storybook/react";

import Button from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/Button",
  component: Button,
  tags: ["autodocs"],
  argTypes: {
    children: {
      control: "text",
      description: "Anidar contenido (texto o elementos HTML).",
    },
    className: {
      control: "text",
      description: "Clases TailwindCSS adicionales para personalizar el estilo",
    },
    onClick: {
      action: "clicked",
      description: "Función que se ejecutara, cuando se haga clic",
    },
    disabled: {
      control: "boolean",
      description: "Permite deshabilitar el botón",
    },
    btnColor: {
      control: {
        type: "select",
        options: ["primary", "secondary", "third"],
      },
      description:
        "Color de estilo del botón (primario, secundario o terciario).",
    },
  },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Primary: Story = {
  args: {
    children: "Primario",
    btnColor: "primary",
  },
};

export const Secondary: Story = {
  args: {
    children: "Secundario",
    btnColor: "secondary",
  },
};

export const Third: Story = {
  args: {
    children: "Terciario",
    btnColor: "third",
  },
};
