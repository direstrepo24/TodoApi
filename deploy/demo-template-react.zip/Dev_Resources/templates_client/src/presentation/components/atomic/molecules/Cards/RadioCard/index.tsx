import { FC } from "react";
import "./index.scss";
import Card from "@presentation/components/atomic/atoms/Card";
import ListTile from "@presentation/components/atomic/atoms/ListTile";
import RadioButton from "@presentation/components/atomic/atoms/RadioButton";

interface RadioCardProps {
  name: string;
  value: string;
  title?: string; //Opcionalmente titulo principal
  subtitle?: string; // Opcionalmente un subtitulo debajo del titulo
  selectedValue?: string | null; // valor selecionado
  onValueChange?: (value: string) => void; // valor del check
}

const RadioCard: FC<RadioCardProps> = ({
  name,
  title,
  subtitle,
  selectedValue,
  value,
  onValueChange,
}) => {
  const handleClick = () => {
    if (onValueChange) onValueChange(value);
  };

  return (
    <Card onClick={handleClick} className="card--size">
      <ListTile
        title={title}
        subtitle={subtitle}
        trailing={
          <RadioButton
            name={name}
            value={value}
            checked={value == selectedValue}
            onChange={handleClick}
          />
        }
      />
    </Card>
  );
};

export default RadioCard;
