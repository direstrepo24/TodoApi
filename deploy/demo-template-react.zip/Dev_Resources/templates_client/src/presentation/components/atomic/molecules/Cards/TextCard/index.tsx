import { FC } from "react";
import "./index.scss";
import Card from "@presentation/components/atomic/atoms/Card";
import ListTile from "@presentation/components/atomic/atoms/ListTile";

interface TextCardProps {
  id?: string;
  title?: string; //Opcionalmente titulo principal
  subtitle?: string; // Opcionalmente un subtitulo debajo del titulo
  subtitleTrailing?: string; //Opcionalmente para mostrar despues del titulo
}

const TextCard: FC<TextCardProps> = ({
  id,
  title,
  subtitle,
  subtitleTrailing,
}) => {
  return (
    <Card id={id} className="card--size">
      <ListTile
        title={title}
        subtitle={subtitle}
        trailing={
          <div className="text-card--subtitletrailing">{subtitleTrailing}</div>
        }
      ></ListTile>
    </Card>
  );
};

export default TextCard;
