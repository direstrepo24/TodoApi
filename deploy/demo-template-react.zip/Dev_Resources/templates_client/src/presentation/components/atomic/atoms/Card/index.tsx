import { DetailedHTMLProps, FC, HTMLAttributes } from "react";
import "./index.scss";
import classNames from "classnames";

interface CardProps
  extends DetailedHTMLProps<HTMLAttributes<HTMLDivElement>, HTMLDivElement> {}

const Card: FC<CardProps> = ({ children, className, ...props }) => {
  const cardClass = classNames("tuya-card", className);
  return (
    <div {...props} className={cardClass}>
      {children}
    </div>
  );
};

export default Card;
