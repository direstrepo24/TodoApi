import { MouseEventHandler } from "react";
import {
  Button,
  CaptionDropdowns,
  CaptionProps,
  IconLeft,
  IconRight,
  useDayPicker,
  useNavigation,
} from "react-day-picker";

export function CustomCaption(props: Readonly<CaptionProps>): JSX.Element {
  const { previousMonth, nextMonth, goToMonth } = useNavigation();

  const {
    locale,
    classNames,
    styles,
    labels: { labelPrevious, labelNext },
  } = useDayPicker();

  const previousLabel = labelPrevious(previousMonth, { locale });
  const previousClassName = [
    classNames.nav_button,
    classNames.nav_button_previous,
  ].join(" ");

  const nextLabel = labelNext(nextMonth, { locale });
  const nextClassName = [
    classNames.nav_button,
    classNames.nav_button_next,
  ].join(" ");

  const handlePreviousClick: MouseEventHandler = () => {
    if (!previousMonth) return;
    goToMonth(previousMonth);
  };

  const handleNextClick: MouseEventHandler = () => {
    if (!nextMonth) return;
    goToMonth(nextMonth);
  };
  return (
    <div className="flex justify-between">
      <Button
        name="previous-month"
        aria-label={previousLabel}
        className={previousClassName}
        style={styles.nav_button_previous}
        disabled={!previousMonth}
        onClick={handlePreviousClick}
      >
        <IconLeft className={classNames.nav_icon} style={styles.nav_icon} />
      </Button>
      <CaptionDropdowns
        displayMonth={props.displayMonth}
        displayIndex={props.displayIndex}
        id={props.id}
      />
      <Button
        name="next-month"
        aria-label={nextLabel}
        className={nextClassName}
        style={styles.nav_button_next}
        disabled={!nextMonth}
        onClick={handleNextClick}
      >
        <IconRight className={classNames.nav_icon} style={styles.nav_icon} />
      </Button>
    </div>
  );
}
