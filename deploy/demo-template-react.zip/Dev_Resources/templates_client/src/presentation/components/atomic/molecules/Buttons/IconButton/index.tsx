import Icon, {
  IconProps,
  IconSize,
} from "@presentation/components/atomic/atoms/Icons";
import Button, { ButtonProps } from "../../../atoms/Button";
import "./index.scss";
import { ReactNode } from "react";
export interface IconButtonProps extends ButtonProps {
  icon?: IconProps["icon"];
  iconSize?: IconSize;
  iconChildren?: ReactNode;
  label?: string;
}
const IconButton = ({
  icon = "plata",
  iconSize = "32",
  iconChildren,
  label,
  ...props
}: Readonly<IconButtonProps>) => {
  return (
    <Button {...props}>
      <div className="tuya-btn-icon">
        {iconChildren ?? <Icon iconSize={iconSize} icon={icon} />}
        <span className="tuya-btn-icon__label">{label}</span>
      </div>
    </Button>
  );
};
export default IconButton;
