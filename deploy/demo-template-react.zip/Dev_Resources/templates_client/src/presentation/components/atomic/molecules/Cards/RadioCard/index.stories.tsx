import type { Meta, StoryObj } from "@storybook/react";

import RadioCard from "./index";
import { useState } from "react";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/RadioCard",
  component: RadioCard,
  tags: ["autodocs"],
  argTypes: {
    name: {
      control: "text",
      description:
        "Identificador del componente, sirve para agregar varios RadioCard a un mismo grupo",
    },
    title: {
      control: "text",
      description: "Titulo",
    },
    subtitle: {
      control: "text",
      description: "Subtitulo",
    },
    selectedValue: {
      control: "boolean",
      description: "Valor seleccionado",
    },
    onValueChange: {
      action: "function",
      description: "Función que se ejecutara, cuando se haga clic",
    },
  },
} satisfies Meta<typeof RadioCard>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args
const DefaultExample = ({ ...parameters }) => {
  const [selected, setSelected] = useState<string>();

  return (
    <RadioCard
      {...parameters}
      name={parameters.name}
      value={parameters.value}
      selectedValue={selected}
      onValueChange={setSelected}
    />
  );
};

export const Default: Story = {
  args: {
    name: "RadioCard1",
    title: "Titulo",
    subtitle: "Subtitulo",
    value: "value",
  },
  render: DefaultExample,
};

const HandlingChangeExample = ({ ...parameters }) => {
  const [selected, setSelected] = useState<string>();

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "12px",
      }}
    >
      <RadioCard
        {...parameters}
        name={parameters.name}
        value={parameters.value}
        selectedValue={selected}
        onValueChange={setSelected}
      />
      <RadioCard
        name="test2"
        value="test2"
        title="test 2"
        subtitle="lorem ipsum"
        selectedValue={selected}
        onValueChange={setSelected}
      />
    </div>
  );
};

export const ChoosingCards: Story = {
  args: {
    title: "Lorem",
    subtitle: "ipsum",
    name: "test",
    value: "test",
  },
  render: HandlingChangeExample,
};
