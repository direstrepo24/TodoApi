import type { Meta, StoryObj } from "@storybook/react";

import DateInput from "./index";
import { useState } from "react";
import { DateRange } from "react-day-picker";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/DateInput",
  component: DateInput,
  tags: ["autodocs"],
  argTypes: {
    error: {
      control: "text",
      description: "Permite mostrar un mensaje de error",
    },
    placeholder: {
      control: "text",
      description: "Permite asociar un texto de etiqueta al campo de entrada",
    },
    label: {
      control: "text",
      description:
        "Esta propiedad permite asociar un texto de etiqueta al campo de entrada",
    },
    selected: {
      control: {
        type: "date",
      },
      description: "Parámetro encargado de obtener el valor seleccionado",
    },
    onSelect: {
      action: "function",
      description: "Parámetro encargado de obtener el nuevo valor seleccionado",
    },
    mode: {
      options: ["single", "range", "multiple"],
      control: {
        type: "select",
      },
      description: "Parámetro encargado de definir el tipo de input a usar",
    },
    maxDate: {
      control: "date",
      description: "limite superior para la elección de fechas",
    },
    minDate: {
      control: "date",
      description: "limite inferior para la elección de fechas",
    },
  },
} satisfies Meta<typeof DateInput>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

const DateInputSingleExample = ({ ...parameters }) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  return (
    <DateInput
      {...parameters}
      mode="single"
      selected={selectedDate}
      onSelect={setSelectedDate}
    />
  );
};

export const Single: Story = {
  args: {
    mode: "single",
    placeholder: "Selecciona tu fecha",
    label: "Selecciona tu fecha",
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 500,
        background: "inherit",
      },
    },
  },
  render: DateInputSingleExample,
};

const DateInputRangeExample = ({ ...parameters }) => {
  const [selectedDate, setSelectedDate] = useState<DateRange | undefined>();
  return (
    <DateInput
      {...parameters}
      mode="range"
      selected={selectedDate}
      onSelect={setSelectedDate}
    />
  );
};

export const Range: Story = {
  args: {
    mode: "range",
    placeholder: "Selecciona tu fecha",
    label: "Selecciona tu fecha",
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 500,
        background: "inherit",
      },
    },
  },
  render: DateInputRangeExample,
};

const DateInputMultipleExample = ({ ...parameters }) => {
  const [selectedDate, setSelectedDate] = useState<Date[] | undefined>();
  return (
    <DateInput
      {...parameters}
      mode="multiple"
      selected={selectedDate}
      onSelect={setSelectedDate}
    />
  );
};

export const Multiple: Story = {
  args: {
    mode: "multiple",
    placeholder: "Selecciona tu fecha",
    label: "Selecciona tu fecha",
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 500,
        background: "inherit",
      },
    },
  },
  render: DateInputMultipleExample,
};

export const AddingLimits: Story = {
  args: {
    mode: "single",
    placeholder: "Selecciona tu fecha",
    label: "Selecciona tu fecha",
    minDate: new Date(2014, 0, 5),
    maxDate: new Date(2014, 10, 3),
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 500,
        background: "inherit",
      },
    },
  },
  render: DateInputSingleExample,
};

export const ErrorStory: Story = {
  args: {
    mode: "single",
    placeholder: "Selecciona tu fecha",
    label: "Selecciona tu fecha",
    error: "Debes elegir una fecha apta",
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 500,
        background: "inherit",
      },
    },
  },
  name: "Error",
  render: DateInputSingleExample,
};
