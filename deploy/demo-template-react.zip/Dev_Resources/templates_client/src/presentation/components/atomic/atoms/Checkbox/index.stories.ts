import type { Meta, StoryObj } from "@storybook/react";

import Checkbox from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Atoms/Checkbox",
  component: Checkbox,
  tags: ["autodocs"],
  argTypes: {
    name: {
      control: "text",
      description: "Contenido del botón (texto o elementos React).",
    },
    defaultValue: {
      control: "boolean",
      description: "Valor por defecto asociado al Checkbox",
    },
    disabled: {
      control: "boolean",
      description:
        "Esta propiedad especifica si el checkbox debe estar deshabilitado",
    },
    onValueChange: {
      action: "function",
      description: "Función que se ejecutara, cuando se haga clic",
    },
  },
} satisfies Meta<typeof Checkbox>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Default: Story = {
  args: {
    name: "checkbox",
  },
};
