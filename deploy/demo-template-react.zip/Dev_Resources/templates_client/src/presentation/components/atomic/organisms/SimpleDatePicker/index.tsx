import { FC, useRef } from "react";
import { format, getMonth, getYear, isAfter } from "date-fns";

import "./index.scss";
import SelectInput from "../../molecules/SelectInput";
import { useSimpleDatePicker } from "./hooks/useSimpleDatePicker";

interface SimpleDatePickerProps {
  minDate?: Date;
  maxDate?: Date;
  error?: string;
  date?: Date;
  onChange?: (newValue: Date) => void;
}

const SimpleDatePicker: FC<SimpleDatePickerProps> = ({
  minDate = new Date(getYear(new Date()) - 10, 0, 1),
  maxDate = new Date(getYear(new Date()) + 10, 11, 31),
  error,
  date,
  onChange,
}) => {
  if (isAfter(minDate, maxDate)) {
    throw new Error("La fecha mínima no puede ser mayor que la fecha máxima");
  }
  const minDateRef = useRef(minDate);
  const maxDateRef = useRef(maxDate);
  const { years, months, selectedDate, handleChange, days } =
    useSimpleDatePicker({
      minDate: minDateRef.current,
      maxDate: maxDateRef.current,
      value: date,
      onChange,
    });

  return (
    <div className="tuya-simple-date-picker">
      <div className="tuya-simple-date-picker__container">
        <SelectInput
          className="tuya-simple-date-picker__year-select"
          label="Año"
          aria-label="Año"
          name="year"
          placeholder="2014"
          options={years}
          onChange={handleChange}
          value={
            selectedDate && {
              value: getYear(selectedDate),
              label: getYear(selectedDate).toString(),
            }
          }
          hasError={!!error}
          blurInputOnSelect
        />
        <SelectInput
          className="tuya-simple-date-picker__month-select"
          label="Mes"
          aria-label="Mes"
          name="month"
          placeholder="Enero"
          options={months}
          onChange={handleChange}
          value={
            selectedDate &&
            months.find((month) => getMonth(selectedDate) === month.value)
          }
          hasError={!!error}
          blurInputOnSelect
        />
        <SelectInput
          className="tuya-simple-date-picker__day-select"
          label="Día"
          aria-label="Día"
          name="day"
          placeholder="10"
          options={days}
          onChange={handleChange}
          value={
            selectedDate && {
              value: Number(format(selectedDate, "d")),
              label: format(selectedDate, "d"),
            }
          }
          hasError={!!error}
          blurInputOnSelect
        />
      </div>
      <span className="tuya-simple-date-picker__error">{error}</span>
    </div>
  );
};

export default SimpleDatePicker;
