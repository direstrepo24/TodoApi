import type { Meta, StoryObj } from "@storybook/react";

import RadioGroup from "./index";
import { useState } from "react";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/RadioGroup",
  component: RadioGroup,
  tags: ["autodocs"],
  argTypes: {
    name: {
      control: "text",
      description: "Identificador del grupo de radio buttons",
    },
    options: {
      control: {
        type: "object",
      },
      description: "Lista de opciones del radio group",
    },
    labelPosition: {
      control: {
        type: "select",
        options: ["top", "bottom", "left", "right"],
      },
      description: "Permite modificar la posición del label.",
    },
    selectedValue: {
      control: "boolean",
      description: "Valor seleccionado",
    },
    onValueChange: {
      action: "function",
      description: "Función que se ejecutara, cuando se haga clic",
    },
    className: {
      control: "text",
      description: "Clases TailwindCSS adicionales para personalizar el estilo",
    },
  },
} satisfies Meta<typeof RadioGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args
const DefaultExample = ({ ...props }) => {
  const [selected, setSelected] = useState<string>();

  return (
    <RadioGroup
      {...props}
      selectedValue={selected}
      onValueChange={setSelected}
      name={props.name}
      options={props.options}
    />
  );
};

export const Default: Story = {
  args: {
    name: "radiogroup",
    options: [
      { label: "test1", value: "test1" },
      { label: "test2", value: "test2" },
      { label: "test3", value: "test3" },
    ],
    labelPosition: "left",
    selectedValue: "test2",
  },
  render: DefaultExample,
};
