import {
  icoPlata,
  icoSistemaCerrar,
  icoSistemaCheck,
  icoSistemaFlechaadelante,
  icoSistemaNotificacion,
  icoSistemaSuccessCheck,
  icoTarjeta,
  icoWhatsapp,
  icoSistemaFlechaAbajo,
  icoSistemaBuscar,
  icoSistemaCalendario,
} from "@presentation/assets/icons";

export const icons = {
  tarjeta: { src: icoTarjeta.default, alt: "Icono de tarjeta" },
  plata: { src: icoPlata.default, alt: "Icono de billete" },
  sistemaCerrar: { src: icoSistemaCerrar.default, alt: "Icono de una equis" },
  sistemaCheck: {
    src: icoSistemaCheck.default,
    alt: "Icono de un chulo",
  },
  sistemaSuccessCheck: {
    src: icoSistemaSuccessCheck.default,
    alt: "Icono de un chulo verde",
  },
  sistemaNotificacion: {
    src: icoSistemaNotificacion.default,
    alt: "Icono de campana",
  },
  sistemaFlechaadelante: {
    src: icoSistemaFlechaadelante.default,
    alt: "Icono de flecha",
  },
  whatsapp: {
    src: icoWhatsapp.default,
    alt: "Icono con símbolo de logo de WhatsApp",
  },
  icoSistemaFlechaAbajo: {
    src: icoSistemaFlechaAbajo.default,
    alt: "Icono de flecha",
  },
  icoSistemaBuscar: { src: icoSistemaBuscar.default, alt: "Icono de lupa" },
  icoSistemaCalendario: {
    src: icoSistemaCalendario.default,
    alt: "Icono de calendario",
  },
} as const;
