import "./index.scss";
import { FC, useState } from "react";
import classNames from "classnames";

interface CheckboxProps {
  name?: string;
  disabled?: boolean;
  onValueChange?: (value: boolean, name?: string) => void;
  defaultValue?: boolean;
}

const Checkbox: FC<CheckboxProps> = ({
  name,
  disabled = false,
  defaultValue = false,
  onValueChange,
}) => {
  const [checkbox, setCheckbox] = useState<boolean>(defaultValue);
  const handleChange = () => {
    if (disabled) return;
    const value = !checkbox;
    setCheckbox(value);
    if (onValueChange) onValueChange(value, name);
  };

  const style = classNames(
    "tuya-checkbox",
    disabled ? `tuya-checkbox--disabled` : ""
  );

  return (
    <button type="button" className={style} onClick={handleChange}>
      <input
        className="tuya-checkbox__input"
        disabled={disabled}
        type="checkbox"
        checked={checkbox}
      />
      <i className="tuya-checkbox__icon"></i>
    </button>
  );
};

export default Checkbox;
