import { useMemo, useState } from "react";
import { Options, Props } from "react-select";
import { DateOption } from "../../types";
import { getMonth, getYear } from "date-fns";
import {
  setInRangeDate,
  setSelectedDay,
  setSelectedMonth,
  setSelectedYear,
} from "../utils/setters";
import {
  getAvailableDays,
  getAvailableMonths,
  getAvailableYears,
} from "../utils/getAvailableValues";

type OnChange = Props<DateOption, false>["onChange"];

interface UseSimpleDatePickerProps {
  minDate: Date;
  maxDate: Date;
  value?: Date;
  onChange?: (newValue: Date) => void;
}

function useSimpleDatePicker({
  minDate,
  maxDate,
  value,
  onChange,
}: UseSimpleDatePickerProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(value);

  const selectedYear = selectedDate
    ? getYear(selectedDate)
    : setInRangeDate(new Date(), minDate, maxDate).getFullYear();
  const selectedMonth = selectedDate ? getMonth(selectedDate) : 0;

  const years: Options<DateOption> = useMemo(
    () => getAvailableYears({ minDate, maxDate }),
    [minDate, maxDate]
  );

  const months: Options<DateOption> = useMemo(
    () => getAvailableMonths({ selectedYear, minDate, maxDate }),
    [maxDate, minDate, selectedYear]
  );

  const days: Options<DateOption> = useMemo(
    () => getAvailableDays({ selectedYear, selectedMonth, minDate, maxDate }),
    [selectedYear, selectedMonth, maxDate, minDate]
  );

  const handleChange: OnChange = (newValue, action) => {
    const currentNewValue = newValue as DateOption;
    const name = action.name as string;
    if (!selectedDate) {
      const defaultValues = {
        year: selectedYear,
        month: 0,
        day: 1,
      };
      defaultValues[name as keyof typeof defaultValues] = currentNewValue.value;
      const newDate = new Date(
        defaultValues.year,
        defaultValues.month,
        defaultValues.day
      );

      setSelectedDate(newDate);
    } else {
      const setterHandler = {
        year: setSelectedYear,
        month: setSelectedMonth,
        day: setSelectedDay,
      };
      const newDate = setterHandler[name as keyof typeof setterHandler]({
        newValue: currentNewValue.value,
        currentDate: selectedDate,
        minDate,
        maxDate,
      });

      if (newDate.toISOString() !== selectedDate.toISOString()) {
        if (onChange) onChange(newDate);
        setSelectedDate(newDate);
      }
    }
  };

  return {
    selectedDate,
    years,
    months,
    days,
    handleChange,
  };
}

export { useSimpleDatePicker };
