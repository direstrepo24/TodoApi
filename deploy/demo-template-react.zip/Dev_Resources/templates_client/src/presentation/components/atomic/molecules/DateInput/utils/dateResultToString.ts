import { format } from "date-fns";
import { Matcher, isDateRange } from "react-day-picker";

export function dateResultToString(result: Matcher | Matcher[]): string {
  if (isDateRange(result)) {
    if (result.from && result.to) {
      return `${format(result.from, "dd-MM-yyyy")} a ${format(result.to, "dd-MM-yyyy")}`;
    } else {
      return "";
    }
  }

  if (result instanceof Date) {
    return format(result, "dd-MM-yyyy");
  }

  if (Array.isArray(result)) {
    let r: string = "";
    if (result[0] instanceof Date) {
      result.forEach((date, idx) => {
        r += dateResultToString(date);
        if (idx !== result.length - 1) r += ", ";
      });
    }

    return r;
  }

  return "";
}
