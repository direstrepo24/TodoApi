import {
  DetailedHTMLProps,
  FC,
  ImgHTMLAttributes,
  MouseEventHandler,
} from "react";
import "./index.scss";
import { icons } from "./icons";

export type IconSize = "22" | "32" | "48";

export interface IconProps
  extends Omit<
    DetailedHTMLProps<ImgHTMLAttributes<HTMLImageElement>, HTMLImageElement>,
    "src" | "onClick" | "alt"
  > {
  icon?: keyof typeof icons;
  iconSize?: IconSize;
  onClick?: MouseEventHandler<HTMLButtonElement>;
}

const Icon: FC<IconProps> = ({
  icon = "tarjeta",
  iconSize = "32",
  width,
  height,
  className,
  onClick,
  ...props
}) => {
  const finalWidth = width ?? Number(iconSize);
  const finalHeight = height ?? Number(iconSize);
  return !onClick ? (
    <img
      {...props}
      className={`tuya-icon ${className ?? ""}`}
      src={icons[icon].src}
      alt={icons[icon].alt}
      width={finalWidth}
      height={finalHeight}
    />
  ) : (
    <button
      type="button"
      className={`tuya-icon ${className ?? ""}`}
      onClick={onClick}
    >
      <img
        {...props}
        src={icons[icon].src}
        alt={icons[icon].alt}
        width={finalWidth}
        height={finalHeight}
      />
    </button>
  );
};

export default Icon;
