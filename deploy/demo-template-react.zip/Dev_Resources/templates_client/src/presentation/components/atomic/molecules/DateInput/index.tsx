import { FC } from "react";
import "./index.scss";
import classNames from "classnames";
import Icon from "../../atoms/Icons";
import {
  DayPicker,
  DayPickerSingleProps,
  DayPickerMultipleProps,
  DayPickerRangeProps,
} from "react-day-picker";
import { es } from "date-fns/locale";
import { default as defaultStyles } from "react-day-picker/dist/style.module.css";
import { dateResultToString } from "./utils/dateResultToString";
import Input from "../../atoms/Input";
import { getYear, isAfter } from "date-fns";
import { CustomCaption, CustomDropdown } from "./components";

type Single = DayPickerSingleProps & BaseDateInputProps;
type Multiple = DayPickerMultipleProps & BaseDateInputProps;
type Range = DayPickerRangeProps & BaseDateInputProps;

type DateInputProps = Single | Multiple | Range;

export type BaseDateInputProps = {
  label?: string;
  placeholder?: string;
  error?: string;
  minDate?: Date;
  maxDate?: Date;
};

const DateInput: FC<DateInputProps> = ({
  label,
  placeholder,
  error,
  className,
  minDate = new Date(getYear(new Date()) - 10, 0, 1),
  maxDate = new Date(getYear(new Date()) + 10, 11, 31),
  ...props
}) => {
  if (isAfter(minDate, maxDate)) {
    throw new Error("La fecha mínima no puede ser mayor que la fecha máxima");
  }
  return (
    <div className="dropdown tuya-date-select">
      <div
        tabIndex={0}
        role="button"
        className={classNames("tuya-date-select__input", className)}
      >
        <Input
          error={error && " "}
          placeholder={placeholder}
          label={label}
          value={props.selected ? dateResultToString(props.selected) : ""}
          disabled
        />
        <Icon
          icon="icoSistemaCalendario"
          iconSize="22"
          className="tuya-date-select__input-icon"
        />
      </div>
      <div tabIndex={0}>
        <DayPicker
          {...props}
          classNames={{
            ...defaultStyles,
            month: classNames(
              defaultStyles.month,
              "tuya-date-select__calendar-month"
            ),
            nav_button_previous: classNames(
              defaultStyles.nav_button,
              "tuya-date-select__calendar-button"
            ),
            nav_button_next: classNames(
              defaultStyles.nav_button,
              "tuya-date-select__calendar-button"
            ),
            caption_label: classNames(
              defaultStyles.caption_label,
              "tuya-date-select__calendar-button"
            ),
            day_selected: classNames(
              defaultStyles.day_selected,
              "tuya-date-select__calendar-day--selected"
            ),
            cell: classNames(
              defaultStyles.cell,
              "tuya-date-select__calendar-cell"
            ),
            root: classNames(defaultStyles.root, "tuya-date-select__root"),
          }}
          captionLayout="dropdown-buttons"
          showOutsideDays
          locale={es}
          components={{
            Caption: CustomCaption,
            Dropdown: CustomDropdown,
          }}
          className="tuya-date-select__calendar"
          toDate={maxDate}
          fromDate={minDate}
        />
      </div>

      {error && (
        <div className="tuya-date-select__error">
          <span className="tuya-date-select__error__label">{error}</span>
        </div>
      )}
    </div>
  );
};

export default DateInput;
