import { InputHTMLAttributes, DetailedHTMLProps, FC } from "react";
import Icon, { IconProps } from "../../atoms/Icons";
import "./index.scss";
import classNames from "classnames";

interface SearchInputProps
  extends Omit<
    DetailedHTMLProps<InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>,
    "type" | "onClick"
  > {
  onClick?: IconProps["onClick"];
}

const SearchInput: FC<SearchInputProps> = ({
  className,
  onClick,
  placeholder = "Buscar",
  ...props
}) => {
  return (
    <label className={classNames("flex tuya-input-search", className)}>
      <input {...props} type="text" placeholder={placeholder} />
      <Icon icon="icoSistemaBuscar" {...(onClick && { onClick })} />
    </label>
  );
};

export default SearchInput;
