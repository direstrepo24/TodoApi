import type { Meta, StoryObj } from "@storybook/react";

import Select from "./index";

// More on how to set up stories at: https://storybook.js.org/docs/react/writing-stories/introduction
const meta = {
  title: "Tuya Template/Molecules/SelectInput",
  component: Select,
  tags: ["autodocs"],
  argTypes: {
    error: {
      control: "text",
      description: "Permite mostrar un mensaje de error",
    },
    hasError: {
      control: "boolean",
      description: "Permite demarcar que hay un error sin mostrar un mensaje",
    },
    options: {
      control: "object",
      description: "Lista de elementos a seleccionar",
    },
    label: {
      control: "text",
      description: "Permite asociar un texto de etiqueta al campo de entrada",
    },
    placeholder: {
      control: "text",
      description:
        "Permite mostrar un mensaje antes de seleccionar el primer elemento",
      defaultValue: "Select...",
    },
  },
} satisfies Meta<typeof Select>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/react/writing-stories/args

export const Default: Story = {
  args: {
    label: "¿Cuál es tu ocupación?",
    options: [
      { label: "Estudiante", value: "1" },
      { label: "Empleado tiempo completo", value: "2" },
      { label: "Empleado tiempo parcial", value: "3" },
      { label: "Trabajador independiente", value: "4" },
      { label: "Empresario", value: "5" },
      { label: "Profesional", value: "6" },
    ],
    placeholder: "Seleccione una ocupación...",
  },
  parameters: {
    docs: {
      story: {
        inline: false,
        iframeHeight: 400,
        background: "inherit",
      },
    },
  },
};

export const ErrorStory: Story = {
  args: {
    label: "¿Cuál es tu ocupación?",
    options: [
      { label: "Estudiante", value: "1" },
      { label: "Empleado tiempo completo", value: "2" },
      { label: "Empleado tiempo parcial", value: "3" },
      { label: "Trabajador independiente", value: "4" },
      { label: "Empresario", value: "5" },
      { label: "Profesional", value: "6" },
    ],
    error: "Debes de elegir una ocupación",
  },
  name: "Error",
};
