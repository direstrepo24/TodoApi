import React, { FC } from "react";
import "./index.scss";
import classNames from "classnames";

type InputType = "text" | "number";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  type?: InputType;
  label?: string;
  className?: string;
  error?: string;
}

const Input: FC<InputProps> = ({
  type = "text",
  label,
  className,
  error,
  ...props
}) => {
  const inputClass = classNames(
    "tuya-input__field",
    error && "tuya-input__field--error",
    className
  );

  return (
    <>
      <div className="tuya-input">
        <input {...props} className={inputClass} type={type} />
        <label className="tuya-input__label">{label}</label>
      </div>
      {error && (
        <div className="tuya-input__error">
          <span className="tuya-input__error__label">{error}</span>
        </div>
      )}
    </>
  );
};
export default Input;
