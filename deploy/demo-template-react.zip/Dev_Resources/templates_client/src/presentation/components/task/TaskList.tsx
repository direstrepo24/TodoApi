import { TaskDom } from "@domain/tasks";
import Icon from "../atomic/atoms/Icons";
interface TaskListProps {
  items: TaskDom[];
  onComplete: (task: TaskDom) => void;
  onDelete: (task: TaskDom) => void;
}
const TaskList = ({
  items = [],
  onComplete,
  onDelete,
}: Readonly<TaskListProps>) => {
  return (
    <div className="w-full">
      {items.map((task) => (
        <li key={task.id} className="item-list bg-white">
          <Icon
            icon={task.completed ? "sistemaSuccessCheck" : "sistemaCheck"}
            onClick={() => onComplete(task)}
          ></Icon>
          <p
            className={`item-list-p  ${task.completed ? "item-list-p--complete" : ""} `}
          >
            {task.name}
          </p>
          <Icon icon="sistemaCerrar" onClick={() => onDelete(task)}></Icon>
        </li>
      ))}
    </div>
  );
};
export default TaskList;
