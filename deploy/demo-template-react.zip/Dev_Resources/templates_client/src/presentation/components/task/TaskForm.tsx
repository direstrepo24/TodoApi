import { CreateTaskRequestDom } from "@domain/tasks";
import * as Yup from "yup";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import Input from "../atomic/atoms/Input";
import Button from "../atomic/atoms/Button";
import Checkbox from "../atomic/atoms/Checkbox";
import { useTranslation } from "react-i18next";

interface TaskFormProps {
  onCreate: (task: CreateTaskRequestDom) => void;
}
const TaskForm = ({ onCreate }: Readonly<TaskFormProps>) => {
  const { t } = useTranslation();
  const ts = (key: string, params?: object) =>
    params ? t(key, params) : t(key) ?? "";

  const validationSchema = Yup.object().shape({
    name: Yup.string()
      .required(ts("validations.required"))
      .min(3, ts("validations.minLength", { value: 3 }))
      .max(50, ts("validations.maxLength", { value: 50 })),
    complete: Yup.boolean().default(false),
  });
  const {
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<CreateTaskRequestDom>({
    resolver: yupResolver(validationSchema),
  });
  const onSubmit = (data: CreateTaskRequestDom) => onCreate(data);
  return (
    <form className="form-control max-w-xs">
      <span>Formulario de tareas</span>
      <div className="grid grid-cols-1 gap-4">
        <div>
          <Input
            name="name"
            onValueChange={(value) => setValue("name", value)}
            error={errors.name?.message}
            label="Descripcion de la tarea"
            placeholder="ingresa aqui la descripcion"
          />
        </div>
        <div>
          <div className="flex items-left">
            <span className="mr-3">¿ Finalizada ?</span>
            <Checkbox
              name="complete"
              onValueChange={(value) => setValue("complete", value)}
            />
          </div>
        </div>
        <div>
          <Button onClick={handleSubmit(onSubmit)}>Crear Tarea</Button>
          <br></br>
          <br></br>
        </div>
      </div>
    </form>
  );
};
export default TaskForm;
