import { useState } from "react";
import SearchInput from "../atomic/molecules/SearchInput";
import "./index.scss";
import SelectInput from "../atomic/molecules/SelectInput";
import SimpleDatePicker from "../atomic/organisms/SimpleDatePicker";
import { addMonths, isWithinInterval, addDays } from "date-fns";
import DateInput from "../atomic/molecules/DateInput";
import { DateRange } from "react-day-picker";

const Example = () => {
  return (
    <div className="example">
      <h1>Nuevos componentes</h1>
      <SearchProduct />
      <SetPaymentDay />
      <GetPurchases />
      <FilterCategory />
    </div>
  );
};
export default Example;

const SearchProduct = () => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");

  const products = [
    {
      name: "Banano 🍌",
      price: 200,
    },
    {
      name: "Naranja 🍊",
      price: 500,
    },
    {
      name: "Manzana 🍎",
      price: 300,
    },
    {
      name: "Pera 🍐",
      price: 400,
    },
    {
      name: "Uva 🍇",
      price: 600,
    },
    {
      name: "Sandía 🍉",
      price: 800,
    },
    {
      name: "Melón 🍈",
      price: 700,
    },
    {
      name: "Fresa 🍓",
      price: 450,
    },
    {
      name: "Cereza 🍒",
      price: 750,
    },
    {
      name: "Piña 🍍",
      price: 900,
    },
  ].filter((product) =>
    product.name.toLowerCase().includes(filter.toLowerCase())
  );

  const handleSearch = () => {
    setFilter(search);
  };

  return (
    <section>
      <h2>Buscar por nombre</h2>
      <div>
        <SearchInput
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onClick={handleSearch}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              handleSearch();
            }
          }}
        />
        <ul>
          <li>
            <span>Nombre</span>
            <span>Precio</span>
          </li>
          {products.map((product) => (
            <li>
              <span>{product.name}</span>
              <span>
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  minimumFractionDigits: 2,
                  currency: "USD",
                }).format(product.price)}
              </span>
            </li>
          ))}
          {products.length === 0 && <li>No hay elementos que coincidan</li>}
        </ul>
      </div>
    </section>
  );
};

const FilterCategory = () => {
  const options = [
    {
      label: "Todos",
      value: "Todos",
    },
    {
      label: "Fruta",
      value: "Fruta",
    },
    {
      label: "Verdura",
      value: "Verdura",
    },
    {
      label: "Carne",
      value: "Carne",
    },
    {
      label: "Pescado",
      value: "Pescado",
    },
    {
      label: "Cereal",
      value: "Cereal",
    },
  ];
  const [selectedFilter, setSelectedFilter] = useState<
    (typeof options)[0] | null
  >(options[0]);

  const products = [
    {
      name: "Banano 🍌",
      category: "Fruta",
    },
    {
      name: "Naranja 🍊",
      category: "Fruta",
    },
    {
      name: "Zanahoria 🥕",
      category: "Verdura",
    },
    {
      name: "Brócoli 🥦",
      category: "Verdura",
    },
    {
      name: "Pollo 🍗",
      category: "Carne",
    },
    {
      name: "Salmón 🐟",
      category: "Pescado",
    },
    {
      name: "Leche 🥛",
      category: "Lácteo",
    },
    {
      name: "Queso 🧀",
      category: "Lácteo",
    },
    {
      name: "Pan 🍞",
      category: "Cereal",
    },
    {
      name: "Arroz 🍚",
      category: "Cereal",
    },
  ].filter((product) => {
    if (selectedFilter?.value === "Todos") return true;
    return product.category === selectedFilter?.value;
  });

  return (
    <section>
      <h2>Filtrar por categoría</h2>
      <div>
        <SelectInput
          options={options}
          label="Categoría"
          placeholder="Selecciona..."
          value={selectedFilter}
          onChange={(newCategory) => setSelectedFilter(newCategory)}
        />

        <ul>
          <li>Nombre</li>
          {products.map((product) => (
            <li>
              <span>{product.name}</span>
            </li>
          ))}
          {products.length === 0 && <li>No hay elementos que coincidan</li>}
        </ul>
      </div>
    </section>
  );
};

const SetPaymentDay = () => {
  const minDate = new Date();
  const maxDate = addMonths(minDate, 2);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const isRight =
    selectedDate &&
    isWithinInterval(selectedDate, {
      start: addDays(minDate, -1),
      end: maxDate,
    });
  return (
    <section>
      <h2>Selecciona fecha de pago</h2>
      <p>
        Desde la fecha hasta dentro de dos meses, debes seleccionar una fecha de
        pago de tus deberes
      </p>
      <div>
        <SimpleDatePicker
          date={selectedDate}
          onChange={setSelectedDate}
          minDate={minDate}
          maxDate={maxDate}
        />

        <p className="text-xl self-center">
          {selectedDate &&
            (isRight
              ? "La fecha está dentro del rango permitido 🎉"
              : "La fecha está por fuera del rango permitido 🔴")}
        </p>
      </div>
    </section>
  );
};

const GetPurchases = () => {
  const [selectedDates, setSelectedDates] = useState<DateRange | undefined>();

  const products = [
    {
      name: "Banano 🍌",
      category: "Fruta",
      date: "2023-01-15",
    },
    {
      name: "Naranja 🍊",
      category: "Fruta",
      date: "2023-02-20",
    },
    {
      name: "Zanahoria 🥕",
      category: "Verdura",
      date: "2023-03-10",
    },
    {
      name: "Brócoli 🥦",
      category: "Verdura",
      date: "2023-04-05",
    },
    {
      name: "Pollo 🍗",
      category: "Carne",
      date: "2023-05-18",
    },
    {
      name: "Salmón 🐟",
      category: "Pescado",
      date: "2023-06-22",
    },
    {
      name: "Leche 🥛",
      category: "Lácteo",
      date: "2023-07-30",
    },
    {
      name: "Queso 🧀",
      category: "Lácteo",
      date: "2023-08-15",
    },
    {
      name: "Pan 🍞",
      category: "Cereal",
      date: "2023-09-10",
    },
    {
      name: "Arroz 🍚",
      category: "Cereal",
      date: "2023-10-05",
    },
    {
      name: "Manzana 🍎",
      category: "Fruta",
      date: "2023-11-20",
    },
    {
      name: "Pera 🍐",
      category: "Fruta",
      date: "2023-12-25",
    },
    {
      name: "Uva 🍇",
      category: "Fruta",
      date: "2024-01-15",
    },
    {
      name: "Sandía 🍉",
      category: "Fruta",
      date: "2024-02-20",
    },
    {
      name: "Melón 🍈",
      category: "Fruta",
      date: "2024-03-10",
    },
    {
      name: "Fresa 🍓",
      category: "Fruta",
      date: "2024-04-05",
    },
    {
      name: "Cereza 🍒",
      category: "Fruta",
      date: "2024-05-18",
    },
    {
      name: "Piña 🍍",
      category: "Fruta",
      date: "2024-06-22",
    },
    {
      name: "Tomate 🍅",
      category: "Verdura",
      date: "2024-07-30",
    },
    {
      name: "Pepino 🥒",
      category: "Verdura",
      date: "2024-08-15",
    },
  ].filter((product) => {
    if (selectedDates && selectedDates.from && selectedDates.to) {
      return isWithinInterval(new Date(product.date), {
        start: selectedDates.from,
        end: selectedDates.to,
      });
    }
    return true;
  });

  return (
    <section>
      <h2>Obtener compras</h2>
      <div>
        <DateInput
          mode="range"
          selected={selectedDates}
          onSelect={setSelectedDates}
          label="Selecciona tus fechas"
          placeholder="Selecciona tus fechas"
        />
        <ul>
          <li>
            <span>Nombre</span>
            <span>Fecha de compra</span>
          </li>
          {products.map((product) => (
            <li>
              <span>{product.name}</span>
              <span>{product.date}</span>
            </li>
          ))}
          {products.length === 0 && <li>No hay elementos que coincidan</li>}
        </ul>
      </div>
    </section>
  );
};
