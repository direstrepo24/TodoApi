import Example from "@presentation/components/base/Example";

function TaskPage() {
  return <Example />;
}
export default TaskPage;
